﻿#define HTTP
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Net;

namespace UserServiceLibrary
{
    [ServiceContract]
    public class UserService
    {
        static Users _users = new Users();

        [WebGet(UriTemplate = "/users")]
        [OperationContract]
        public Users GetAllUsers()
        {

            return _users;
        }
        [WebInvoke(UriTemplate = "/users", Method = "POST")]
        [OperationContract]
        public User AddNewUser(User u)
        {
            u.UserId = Guid.NewGuid().ToString();
            u.LastModified = DateTimeOffset.Now;
#if HTTP
            OutgoingWebResponseContext ctx = WebOperationContext.Current.OutgoingResponse;
            ctx.SetStatusAsCreated(CreateUri(u));
#endif
            _users.Add(u);
            return u;
        }
        void SetETag(string etag)
        {
            OutgoingWebResponseContext ctx =
                WebOperationContext.Current.OutgoingResponse;
            ctx.ETag = etag;
        }
        string GenerateETag(User u)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(u.UserId + u.LastModified.ToString());
            byte[] hash = MD5.Create().ComputeHash(bytes);
            string etag = Convert.ToBase64String(hash);
            return etag;
        }

        private Uri CreateUri(User u)
        {
            UriTemplate ut = new UriTemplate("/users/{user_id}");
            Uri baseUri = WebOperationContext.Current.IncomingRequest.UriTemplateMatch.BaseUri;
            Uri ret = ut.BindByPosition(baseUri, u.UserId);
            return ret;
        }

       
        [WebGet(UriTemplate = "/users/{user_id}")]
        [OperationContract]
        public User GetUser(string user_id)
        {
            User u = FindUser(user_id);
#if HTTP
            if (CheckLastModified(u))
                return null;
            string etag = GenerateETag(u);
            if (CheckETag(etag))
                return null;
            if (u == null)
            {
                OutgoingWebResponseContext ctx = WebOperationContext.Current.OutgoingResponse;
                ctx.SetStatusAsNotFound();
                ctx.SuppressEntityBody = true;
            }
            SetLastModified(u);
            SetETag(etag);
#endif
            return u;
        }

        private void SetLastModified(User u)
        {
            OutgoingWebResponseContext ctx =
                WebOperationContext.Current.OutgoingResponse;
            ctx.LastModified = u.LastModified.DateTime;
        }

        private bool CheckLastModified(User u)
        {
            IncomingWebRequestContext ctx = WebOperationContext.Current.IncomingRequest;
            string lastModified =
                ctx.Headers[HttpRequestHeader.IfModifiedSince];
            if (lastModified != null)
            {
                DateTimeOffset dt = DateTimeOffset.Parse(lastModified);
                if (InternalDateTimeCompare(u.LastModified.UtcDateTime, dt))
                {
                    SetNotModified();
                    return true;
                }
            }
            return false;
        }

        private bool InternalDateTimeCompare(DateTime dateTime, DateTimeOffset dt)
        {
            DateTime nd1 =
                new DateTime(dateTime.Year, dateTime.Month,
                    dateTime.Day, dateTime.Hour,
                    dateTime.Minute, dateTime.Second);
            DateTime nd2 =
                new DateTime(dt.Year, dt.Month,
                    dt.Day, dt.Hour,
                    dt.Minute, dt.Second);
            return nd1 == nd2;
        }
        private bool CheckETag(string currentETag)
        {
            IncomingWebRequestContext ctx =
                WebOperationContext.Current.IncomingRequest;
            string incomingEtag =
                ctx.Headers[HttpRequestHeader.IfNoneMatch];
            if (incomingEtag != null)
            {
                if (currentETag == incomingEtag)
                {
                    SetNotModified();
                    return true;
                }
            }
            return false;
        }

        private void SetNotModified()
        {
            OutgoingWebResponseContext ctx =
                WebOperationContext.Current.OutgoingResponse;
            ctx.SuppressEntityBody = true;
            ctx.StatusCode = HttpStatusCode.NotModified;
        }

        User FindUser(string user_id)
        {
            User ret = null;
            if (_users.Count > 0)
            {
                var result = (from u in _users
                              where u.UserId == user_id
                              select u);
                if (result != null)
                    ret = result.Single();
            }

            return ret;

        }
        [WebInvoke(UriTemplate = "/users/{user_id}", Method = "PUT")]
        [OperationContract]
        public User UpdateUser(string user_id, User update)
        {
            User u = FindUser(user_id);
            UpdateUserInternal(u, update);
            return u;
        }

        private void UpdateUserInternal(User u, User update)
        {
            u.Email = update.Email;
            u.FirstName = update.FirstName;
            u.LastName = update.LastName;

        }
        [WebInvoke(UriTemplate = "/users/{user_id}", Method = "DELETE")]
        [OperationContract]
        public void DeleteUser(string user_id)
        {
            User u = FindUser(user_id);
            _users.Remove(u);

        }
    }
  
    [CollectionDataContract(Name = "users", Namespace = "")]
    public class Users : List<User>
    {
    }
    [DataContract(Name = "user", Namespace = "")]
    public class User
    {
        [DataMember(Name = "id", Order = 1)]
        public string UserId;
        [DataMember(Name = "firstname", Order = 2)]
        public string FirstName;
        [DataMember(Name = "lastname", Order = 3)]
        public string LastName;
        [DataMember(Name = "email", Order = 4)]
        public string Email;
        public DateTimeOffset LastModified;
    }
    [DataContract(Name = "group", Namespace = "")]
    public class Group
    {
        [DataMember(Name = "name")]
        public string Name;
        [DataMember]
        public Users Users;

    }
}
