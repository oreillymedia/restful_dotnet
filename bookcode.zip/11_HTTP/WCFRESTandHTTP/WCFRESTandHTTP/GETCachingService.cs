﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;

namespace WCFRESTandHTTP
{
    [ServiceContract()]
    [AspNetCompatibilityRequirements(RequirementsMode=AspNetCompatibilityRequirementsMode.Allowed)]
    public class GETCachingService
    {
        [OperationContract]
        [WebGet(UriTemplate="/")]
        public CacheInfo GetInfo()
        {
            HttpContext.Current.Response.Cache.SetExpires(DateTime.Now.AddSeconds(60));
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.Public);
            HttpContext.Current.Response.Cache.SetETagFromFileDependencies();
           // HttpContext.Current.Response.Cache.AddValidationCallback(
            CacheInfo ret = new CacheInfo();
            ret.TimeGenerated = DateTimeOffset.Now.ToString();
            return ret;
        }
    }

    [DataContract(Namespace="")]
    public class CacheInfo
    {
        [DataMember]
        public string TimeGenerated;
    }

}
