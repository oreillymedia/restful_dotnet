﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace WCFRESTandHTTP
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetExpires(DateTime.Now.AddSeconds(60));
            //Response.Cache.SetMaxAge(new TimeSpan(0,0,30));
            Response.Cache.SetCacheability(HttpCacheability.Public);
            Response.Cache.SetETagFromFileDependencies();
            Response.Cache.SetSlidingExpiration(true);
        }
    }
}
