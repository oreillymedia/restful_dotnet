﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Diagnostics;

namespace OutsideIIS
{
    class Program
    {
        static void Main(string[] args)
        {
            WebServiceHost sh = new WebServiceHost(typeof(SecureService));

            string uri = "https://" + Environment.MachineName + "/wcfrestsecoiis/";
            WebHttpBinding wb = new WebHttpBinding();
            wb.Security.Mode = WebHttpSecurityMode.Transport;
            wb.Security.Transport.ClientCredentialType = HttpClientCredentialType.Ntlm;
            sh.AddServiceEndpoint(typeof(SecureService), wb, uri);
            sh.Open();
            Console.WriteLine("Service running");
            Process.Start(uri);
            Console.ReadLine();
        }
    }
    [ServiceContract(Namespace = "")]
    public class SecureService
    {
        [OperationContract]
        [WebGet(UriTemplate = "/")]
        public string AuthType()
        {
            ServiceSecurityContext securityCtx;
            securityCtx = OperationContext.Current.ServiceSecurityContext;
            string authType = "No security context";
            if (securityCtx != null)
            {
                if (securityCtx.IsAnonymous)
                    authType = "Anonymous";
                else
                    authType = securityCtx.PrimaryIdentity.Name;

            }
            return authType;

        }
    }
}
