﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Web;
using System.ServiceModel;

namespace SecurityClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press enter when service is up and running");
            Console.ReadLine();
            Uri uri =
                        new Uri("https://" + Environment.MachineName  + "/wcfrestsecoiis/");
            WebChannelFactory<SecureService>
                cf = new WebChannelFactory<SecureService>(uri);
            WebHttpBinding wb =
                cf.Endpoint.Binding as WebHttpBinding;
            wb.Security.Transport.ClientCredentialType =
                HttpClientCredentialType.Ntlm;
            wb.Security.Mode =
                WebHttpSecurityMode.Transport;
            SecureService service = cf.CreateChannel();
            string auth = service.AuthType();
            Console.WriteLine(auth);

        }
    }
    [ServiceContract(Namespace = "")]
    public interface SecureService
    {
        [OperationContract]
        [WebGet(UriTemplate = "/")]
         string AuthType();
    }
}
