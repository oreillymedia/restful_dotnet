﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace WCFRestSecurity
{
    [ServiceContract(Namespace = "")]
    public class SecureService
    {
        [OperationContract]
        [WebGet(UriTemplate = "/")]
        public string AuthType()
        {
            ServiceSecurityContext securityCtx;
            securityCtx = OperationContext.Current.ServiceSecurityContext;
            string authType = "No security context";
            if (securityCtx != null)
            {
                if (securityCtx.IsAnonymous)
                    authType = "Anonymous";
                else
                    authType = securityCtx.PrimaryIdentity.Name;

            }
            return authType;

        }
    }
}
