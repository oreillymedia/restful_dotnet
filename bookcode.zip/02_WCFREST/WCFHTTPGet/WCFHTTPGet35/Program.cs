﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Collections.Specialized;

namespace WCFHTTPGet35
{
    class Program
    {
        static void Main(string[] args)
        {
            WebHttpBinding binding;
            binding = new WebHttpBinding();
            WebServiceHost sh;
            sh = new WebServiceHost(typeof(SimpleHTTPService));
            sh.AddServiceEndpoint(typeof(SimpleHTTPService),
                binding,
                "http://localhost:8889/TestHttp");
            sh.Open();
            Console.WriteLine("Simple HTTP Service Listening");
            Console.WriteLine("Press enter to stop service");
            Console.ReadLine();

        }
    }
    [ServiceContract]
    public class SimpleHTTPService
    {

        [OperationContract()]
        [WebGet(UriTemplate = "*")]
        Message AllURIs(Message msg)
        {
            WebOperationContext webCtx;
            webCtx = WebOperationContext.Current;
            IncomingWebRequestContext incomingCtx;
            incomingCtx = webCtx.IncomingRequest;
            string uri;
            uri = incomingCtx.UriTemplateMatch.RequestUri.ToString();
            Console.WriteLine("Request to {0}", uri);
            if (incomingCtx.Method != "GET")
            {
                Console.WriteLine("Incoming Message {0} with method of {1}",
                    msg.GetReaderAtBodyContents().ReadOuterXml(),
                    incomingCtx.Method);
            }
            else
            {
                Console.WriteLine("GET Request - no message Body");
            }
            NameValueCollection query;
            query = incomingCtx.UriTemplateMatch.QueryParameters;
            //print the query string if any
            string queryName;
            if (query.Count != 0)
            {
                Console.WriteLine("QueryString:");
                var enumQ = query.GetEnumerator();
                while (enumQ.MoveNext())
                {
                    queryName = enumQ.Current.ToString();
                    Console.WriteLine("{0} = {1}", queryName, query[queryName]);
                }
            }
            Message response = Message.CreateMessage(
                MessageVersion.None,
                "*",
                "Simple response string");
            OutgoingWebResponseContext outCtx;
            outCtx = webCtx.OutgoingResponse;
            outCtx.Headers.Add("CustomHeader", "Value");
            return response;
        }
    }


}
