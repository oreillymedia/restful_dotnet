﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;

namespace WCFHTTPGet
{
    class Program
    {
        static void Main(string[] args)
        {
            CustomBinding b = new CustomBinding();
            TextMessageEncodingBindingElement msgEncoder;
            msgEncoder = new TextMessageEncodingBindingElement();
            msgEncoder.MessageVersion = MessageVersion.None;
            b.Elements.Add(msgEncoder);
            HttpTransportBindingElement http;
            http = new HttpTransportBindingElement();
            http.ManualAddressing = true;
            b.Elements.Add(http);
            ServiceHost sh = new ServiceHost(typeof(SimpleHTTPService));
            ServiceEndpoint se = null;
            se = sh.AddServiceEndpoint(typeof(SimpleHTTPService),
                b,
                "http://localhost:8889/TestHttp");
            sh.Open();
            Console.WriteLine("Simple HTTP Service Listening");
            Console.WriteLine("Press enter to stop service");
            Console.ReadLine();
        }

        [ServiceContract]
        [ServiceBehavior(AddressFilterMode=AddressFilterMode.Any)]
        public class SimpleHTTPService
        {
            [OperationContract(Action = "*", ReplyAction = "*")]
            Message AllURIs(Message msg)
            {
                HttpRequestMessageProperty httpProps;
                string propName;
                propName = HttpRequestMessageProperty.Name;
                httpProps = msg.Properties[propName] as HttpRequestMessageProperty;
                string uri;
                uri = msg.Headers.To.AbsolutePath;
                Console.WriteLine("Request to {0}", uri);
                if (httpProps.Method != "GET")
                {
                    Console.WriteLine("Incoming Message {0} with method of {1}",
                        msg.GetReaderAtBodyContents().ReadOuterXml(),
                        httpProps.Method);
                }
                else
                {
                    Console.WriteLine("GET Request - no message Body");
                }
                //print the query string if any
                if (httpProps.QueryString != null)
                    Console.WriteLine("QueryString = {0}", httpProps.QueryString);
                Message response = Message.CreateMessage(
                    MessageVersion.None,
                    "*",
                    "Simple response string");
                HttpResponseMessageProperty responseProp;
                responseProp = new HttpResponseMessageProperty();
                responseProp.Headers.Add("CustomHeader", "Value");
                return response;
            }
        }
        public class MyHttpBehavior : IEndpointBehavior
        {
            #region IEndpointBehavior Members

            public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters)
            {
            }

            public void ApplyClientBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.ClientRuntime clientRuntime)
            { }

            public void ApplyDispatchBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.EndpointDispatcher endpointDispatcher)
            {
                endpointDispatcher.AddressFilter = new MatchAllMessageFilter();
            }

            public void Validate(ServiceEndpoint endpoint)
            {
            }
            #endregion
        }

    }
}





