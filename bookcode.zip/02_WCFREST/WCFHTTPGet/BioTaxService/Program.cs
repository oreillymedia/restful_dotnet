﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Web;
using BioTaxonomy;
using System.ServiceModel.Channels;
using System.Xml;
using System.IO;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace BioTaxService
{
    class Program
    {
        static void Main(string[] args)
        {
            WebServiceHost sh = new WebServiceHost(typeof(BioTaxService));
            ServiceEndpoint se = sh.AddServiceEndpoint(typeof(IBioTaxService), new WebHttpBinding(), "http://localhost/BioService/");
            //se.Behaviors.Add(new WebScriptEnablingBehavior());
            sh.Open();
            Console.WriteLine("Service up and running...");
            Console.ReadLine();
        }

    }
    class BioTaxService : IBioTaxService
    {
        #region IBioTaxService Members
        //DataContract and XmlSerializer version
        public DomainList GetRoot()
        {
            DomainList ret = new DomainList();
            string[] domains = new string[] { "Archaea", "Eubacteria", "Eukaryota" };
            foreach (string domain in domains)
            {
                ret.Add(new Domain { Name = domain, Uri = domain });

            }
            return ret;
        }
        //Message Version
        //public Message GetRoot()
        //{
        //    MemoryStream ms = new MemoryStream();
        //    XmlDictionaryWriter xw = XmlDictionaryWriter.CreateTextWriter(ms);
        //    xw.WriteStartDocument();
        //    xw.WriteStartElement("Domains");
        //    string[] domains = new string[] { "Archaea", "Eubacteria", "Eukaryota" };
        //    foreach (string domain in domains)
        //    {
        //        xw.WriteStartElement("Domain");
        //        xw.WriteAttributeString("name", domain);
        //        xw.WriteAttributeString("uri", domain);
        //        xw.WriteEndElement();
        //    }
        //    xw.WriteEndElement();
        //    xw.WriteEndDocument();
        //    xw.Flush();
        //    ms.Position = 0;
        //    XmlDictionaryReader xdr = XmlDictionaryReader.CreateTextReader(ms, XmlDictionaryReaderQuotas.Max);
        //    Message ret = Message.CreateMessage(MessageVersion.None, "*", xdr);
        //    return ret;
        //}
        //hybrid version
        //public Message GetRoot()
        //{
        //    DomainList ret = new DomainList();
        //    string[] domains = new string[] { "Archaea", "Eubacteria", "Eukaryota" };
        //    foreach (string domain in domains)
        //    {
        //        ret.Add(new Domain { Name = domain, Uri = domain });

        //    }
        //    Message realRet = Message.CreateMessage(MessageVersion.None, "*", ret);
        //     return realRet;
        //}
        public System.ServiceModel.Channels.Message GetDomain(string Domain)
        {
            KingdomList list = new KingdomList();
            switch (Domain)
            {
                case "Eukaryota":
                    string[] kingdoms = new string[] { "Animalia", "Fungi", "Amoebozoa", "Plantae", "Chromalveolata", "Rhizaria", "Excavata" };
                    list.AddRange((from s in kingdoms
                                   select new Kingdom { Name = s, Uri = s }));
                    break;
                default:
                    break;
            }
            Message realRet = Message.CreateMessage(MessageVersion.None, "*", list);
            return realRet;

        }

        public System.ServiceModel.Channels.Message GetKingdom(string Domain, string Kingdom)
        {
            throw new NotImplementedException();
        }

        public System.ServiceModel.Channels.Message GetPhylum(string Domain, string Kingdom, string Phylum)
        {
            throw new NotImplementedException();
        }

        public System.ServiceModel.Channels.Message GetClass(string Domain, string Kingdom, string Phylum, string Class)
        {
            throw new NotImplementedException();
        }

        public System.ServiceModel.Channels.Message GetOrder(string Domain, string Kingdom, string Phylum, string Class, string Order)
        {
            throw new NotImplementedException();
        }

        public System.ServiceModel.Channels.Message GetFamily(string Domain, string Kingdom, string Phylum, string Class, string Order, string Family)
        {
            throw new NotImplementedException();
        }

        public System.ServiceModel.Channels.Message GetGenus(string Domain, string Kingdom, string Phylum, string Class, string Order, string Family, string Genus)
        {
            throw new NotImplementedException();
        }

        public System.ServiceModel.Channels.Message GetSpecies(string Domain, string Kingdom, string Phylum, string Class, string Order, string Family, string Genus, string Species)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
