﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Specialized;

namespace ExcercisingUriTemplate
{
    class Program
    {
        static void Main(string[] args)
        {
            TableStepOne();
            //TableTest();
            //BasicTest();
        }
        static Dictionary<UriTemplate, object> MakeTemplates(string[] templateStrings)
        {
            Dictionary<UriTemplate, object> templates =
             new Dictionary<UriTemplate, object>();
            UriTemplate uriTemplate = null;
            string msg = null;
            int lastPathSegment = 0;
            string segment = "ROOT";
            foreach (string template in templateStrings)
            {
                uriTemplate = new UriTemplate(template);
                if (uriTemplate.PathSegmentVariableNames.Count > 0)
                {
                    lastPathSegment = uriTemplate.PathSegmentVariableNames.Count - 1;
                    segment = uriTemplate.PathSegmentVariableNames[lastPathSegment];
                }
                msg = segment + " MATCH!";
                templates.Add(uriTemplate, msg);
            }
            return templates;
        }
        private static void TableStepOne()
        {
            string[] stemplates = new string[]{
"/",
"/{Domain}",
"/{Domain}/{Kingdom}",
"/{Domain}/{Kingdom}/{Phylum}",
"/{Domain}/{Kingdom}/{Phylum}/{Class}",
"/{Domain}/{Kingdom}/{Phylum}/{Class}/{Order}",
"/{Domain}/{Kingdom}/{Phylum}/{Class}/{Order}/{Family}",
"/{Domain}/{Kingdom}/{Phylum}/{Class}/{Order}/{Family}/{Genus}",
"/{Domain}/{Kingdom}/{Phylum}/{Class}/{Order}/{Family}/{Genus}/{Species}"
};
            Dictionary<UriTemplate, object> templates =
              MakeTemplates(stemplates);
            Uri baseUri = new Uri("http://example.org");
            //create the UriTemplateTable
            UriTemplateTable tt = new UriTemplateTable(baseUri);
            //add all the UriTemplate/Value pairs to it
            foreach (var kvp in templates)
            {
                tt.KeyValuePairs.Add(kvp);
            }
            bool done = false;
            while (!done)
            {
                Console.WriteLine("type in a URI to test ('Q' to exit)");
                string uri = Console.ReadLine();
                if (uri == "Q")
                {
                    done = true;
                }
                else
                {
                    Uri testUri = new Uri(uri);
                    UriTemplateMatch match = tt.MatchSingle(testUri);
                    if (match != null)
                    {
                        Console.WriteLine(match.Data);
                    }
                    else
                    {
                        Console.WriteLine("No match found!");
                    }
                }
            }



        }
        delegate void MatchMethod(NameValueCollection results);
        private static void TableTest()
        {
            Uri baseUri = new Uri("http://localhost");
            UriTemplate template = new UriTemplate("/");
            UriTemplate template2 = new UriTemplate("/{levelOne}");
            UriTemplate template3 = new UriTemplate("/{levelOne}/{levelTwo}");
            UriTemplateTable tt = new UriTemplateTable(baseUri);
            Dictionary<UriTemplate, object> templates =
                new Dictionary<UriTemplate, object>();
            MatchMethod d = delegate(NameValueCollection results)
            {
                Console.WriteLine("TopLevel");

            };
            templates.Add(template, d);
            d = delegate(NameValueCollection results)
            {
                Console.WriteLine("LevelOne");
            };
            templates.Add(template2, d);
            d = delegate(NameValueCollection results)
            {
                Console.WriteLine("LevelTwo");
            };
            templates.Add(template3, d);
            foreach (var kvp in templates)
            {
                tt.KeyValuePairs.Add(kvp);
            }
            bool done = false;
            while (!done)
            {
                Console.WriteLine("type in a URI to test ('Q' to exit)");
                string uri = Console.ReadLine();
                if (uri == "Q")
                {
                    done = true;
                }
                else
                {
                    Uri testUri = new Uri(uri);
                    UriTemplateMatch match = tt.MatchSingle(testUri);
                    if (match != null)
                    {
                        d = (MatchMethod)match.Data;
                        d.Invoke(match.BoundVariables);
                    }
                    else
                    {
                        Console.WriteLine("No match found!");
                    }
                }
            }



        }
        static void TopLevel()
        {
            Console.WriteLine("TopLevel");
        }
        static void LevelOne(string levelOne)
        {
            Console.WriteLine("LevelOne");
        }
        static void LevelTwo(string levelOne, string levelTwo)
        {
            Console.WriteLine("LevelTwo");
        }
        private static void BasicTest()
        {
            Uri baseUri = new Uri("http://example.org");
            UriTemplate template = new UriTemplate("/{Domain}/{Kingdom}/{Phylum}/{Class}/{Order}/{Family}/{Genus}/{Species}");
            Console.WriteLine("URI path segments are:");
            foreach (var pathSeg in template.PathSegmentVariableNames)
            {
                Console.WriteLine(pathSeg);
            }
            Console.WriteLine("type in a URI to test");
            string uri = Console.ReadLine();
            Uri testUri = new Uri(uri);
            UriTemplateMatch match = template.Match(baseUri, testUri);
            if (match != null)
            {
                var bound = match.BoundVariables;
                string keyValue;

                foreach (var key in bound.Keys)
                {
                    keyValue = key.ToString();
                    Console.WriteLine("{0} = {1}", keyValue, bound[keyValue]);
                }
            }
            else
                Console.WriteLine("URI not a match");

        }
    }
}
