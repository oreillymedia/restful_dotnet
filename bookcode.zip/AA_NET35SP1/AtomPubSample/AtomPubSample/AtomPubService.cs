﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Syndication;
using System.Collections.ObjectModel;

namespace AtomPubSample
{
    [ServiceContract]
    public class AtomPubService
    {
        [OperationContract]
        [WebGet(UriTemplate = "/")]
        public AtomPub10ServiceDocumentFormatter GetServiceDoc()
        {
            OutgoingWebResponseContext ctx =
                WebOperationContext.Current.OutgoingResponse;
            ctx.ContentType = "application/atomsvc+xml";
            AtomPub10ServiceDocumentFormatter ret = null;
            //create the ServiceDocument type
            ServiceDocument doc =
                new ServiceDocument();
            IncomingWebRequestContext ictx =
                WebOperationContext.Current.IncomingRequest;
            //set the BaseUri to the current request URI
            doc.BaseUri =
                ictx.UriTemplateMatch.RequestUri;
            //create a Collection of resources   
            List<ResourceCollectionInfo> resources =
                 new List<ResourceCollectionInfo>();
            //creat the Blog resource
            ResourceCollectionInfo mainBlog =
                new ResourceCollectionInfo("Blog", new Uri("blog", UriKind.Relative));
            //add the Accepts for this resource
            //remember this is the default if no accepts if present
            mainBlog.Accepts.Add("application/atom+xml;type=entry");
            resources.Add(mainBlog);
            //create the Pictures resource
            ResourceCollectionInfo mainPictures =
                new ResourceCollectionInfo("Pictures", new Uri("pictures", UriKind.Relative));
            //add the Accepts for this resource
            mainPictures.Accepts.Add("image/png");
            mainPictures.Accepts.Add("image/jpeg");
            mainPictures.Accepts.Add("image/gif");
            resources.Add(mainPictures);
            //create the Workspace
            Workspace main = new Workspace("Main", resources);
            //add the Workspace to the Service Document
            doc.Workspaces.Add(main);
            //create a new Collection for the next Workspace
            resources = new List<ResourceCollectionInfo>();
            ResourceCollectionInfo food =
                new ResourceCollectionInfo("Food",
                    new Uri("foodblog", UriKind.Relative));
            resources.Add(food);
            //create the link to the Categories Document
            CategoriesDocument cat =
                CategoriesDocument.Create(new Uri("foodblogcats", UriKind.Relative));
            food.Categories.Add(cat);
            //create the second Workspace
            Workspace foodBlog =
                new Workspace("FoodBlog", resources);
            //add the Workspace to the Service Document
            doc.Workspaces.Add(foodBlog);
            //get the formatter
            ret = doc.GetFormatter()
                as AtomPub10ServiceDocumentFormatter;
            return ret;
        }

        [OperationContract]
        [WebGet(UriTemplate = "/foodblogcats")]
        public AtomPub10CategoriesDocumentFormatter GetCats()
        {
            AtomPub10CategoriesDocumentFormatter ret = null;
            //creat the Collection of Categories
            Collection<SyndicationCategory> cats =
                    new Collection<SyndicationCategory>();
            cats.Add(new SyndicationCategory("sushi"));
            cats.Add(new SyndicationCategory("chinese"));
            cats.Add(new SyndicationCategory("deserts"));
            //create the Categories Document
            //in this case I am specifying fixed="yes"
            //and providing the optional scheme
            CategoriesDocument cat =
                CategoriesDocument.Create(cats, true,
                                "http://commonfoodcategories");
            ret = cat.GetFormatter()
                    as AtomPub10CategoriesDocumentFormatter;
            return ret;
        }
    }
}
