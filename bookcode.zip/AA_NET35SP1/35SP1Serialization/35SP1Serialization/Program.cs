﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization;

namespace _35SP1Serialization
{
    class Program
    {
        static void Main(string[] args)
        {
            User u = new User
            {
                UserId = Guid.NewGuid().ToString(),
                FirstName = "Jon",
                LastName = "Flanders",
                Email = "jon.flanders@gmail.com",
                LastModified = DateTimeOffset.Now
            };

            User friend = new User
            {
                UserId = Guid.NewGuid().ToString(),
                FirstName = "Shannon",
                LastName = "Ahern",
                Email = "shannon.ahern@gmail.com",
                LastModified = DateTimeOffset.Now
            };
            u.Friends.Add(friend);
            DataContractSerializer dcs =
                new DataContractSerializer(typeof(User),
                    null, int.MaxValue, false,
                    true /* preserveObjectReferences */,
                    null);
            friend.Friends.Add(u);

            using (FileStream fs = new FileStream("user.xml", FileMode.Create))
            {

                dcs.WriteObject(fs, u);

            }

        }
    }
    public class User
    {
        public string UserId;
        public string FirstName;
        public string LastName;
        public string Email;
        public DateTimeOffset LastModified;
        public List<User> Friends = new List<User>();
    }
}
