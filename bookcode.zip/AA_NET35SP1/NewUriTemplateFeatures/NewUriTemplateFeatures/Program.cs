﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace NewUriTemplateFeatures
{
    class Program
    {
        static void Main(string[] args)
        {
            WebServiceHost sh = new WebServiceHost(typeof(Service),new Uri( "http://localhost:8080"));
            sh.Open();
            Console.ReadLine();
        }
    }
    [ServiceContract]
    public class Service
    {
        [OperationContract]
        [WebGet(UriTemplate = "/staticsegment/{seg1};{seg2}")]
        public void TemplateTest(string seg1, string seg2)
        {
        }
        [OperationContract]
        [WebGet(UriTemplate = "/staticsegment/{seg1}.json")]
        public void TemplateTest2(string seg1) { 
        }
        [OperationContract]
        [WebGet(UriTemplate = "/staticsegment/{seg1}.{variableext}")]
        public void TemplateTest3(string seg1, string variableext) {
        }

    }
}
