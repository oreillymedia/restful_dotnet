﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.ServiceModel.Description;

namespace WebServiceHostConflict
{
    class Program
    {
        static void Main(string[] args)
        {
            //WebServiceHost sh =
            //    new WebServiceHost(typeof(ServiceType));
            ////Can't use base addresses if more than one contract
            ////new Uri("http://localhost:8080/Hosting"));
            ////Why does this work???
            //sh.AddServiceEndpoint(typeof(IWebOne),
            //                        new WebHttpBinding(),
            //                        "http://localhost:8080/Hosting/webone");
            //sh.AddServiceEndpoint(typeof(IWebTwo),
            //                        new WebHttpBinding(),
            //                        "http://localhost:8080/Hosting/webtwo");
            WebServiceHost sh =
                new WebServiceHost(typeof(ServiceType),
             new Uri("http://localhost:8080/Hosting"));
            //But this doesn't???
            sh.AddServiceEndpoint(typeof(IWebOne),
                                    new WebHttpBinding(),
                                    "webone");
            sh.AddServiceEndpoint(typeof(IWebTwo),
                                    new WebHttpBinding(),
                                    "webtwo");
            sh.Open();
            Console.WriteLine("Service is running");
            Console.ReadLine();
        }
    }

    public class ServiceType : IWebOne, IWebTwo
    {
        string IWebOne.One()
        {
            return "One";
        }
        string IWebTwo.Two()
        {
            return "Two";
        }
    }
    [ServiceContract]
    public interface IWebOne
    {
        [OperationContract]
        [WebGet(UriTemplate = "/conflict")]
        string One();
    }
    [ServiceContract]
    public interface IWebTwo
    {
        [OperationContract]
        [WebGet(UriTemplate = "/conflict")]
        string Two();
    }
    public class MultiServiceContractWebServiceHostFactory : ServiceHostFactory
    {
        public override ServiceHostBase CreateServiceHost(string constructorString, Uri[] baseAddresses)
        {
            //this is ok because IIS hosting only allows one URI
            Uri baseUri = baseAddresses[0];

            ServiceHost sh =
        new ServiceHost(typeof(ServiceType));
            //Can't use base addresses if more than one contract
            //new Uri("http://localhost:8080/Hosting"));
            ServiceEndpoint se = sh.AddServiceEndpoint(typeof(IWebOne),
                                    new WebHttpBinding(),
                                    baseUri.AbsoluteUri.ToString() + "/webone");
            se.Behaviors.Add(new WebHttpBehavior());
            se = sh.AddServiceEndpoint(typeof(IWebTwo),
                                     new WebHttpBinding(),
                                        baseUri.AbsoluteUri.ToString() + "/webtwo");
            se.Behaviors.Add(new WebHttpBehavior());
            return sh;
        }
    }
}
