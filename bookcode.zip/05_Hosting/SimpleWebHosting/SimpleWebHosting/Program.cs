﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Description;
using System.Net.Security;
using System.ServiceModel.Activation;
using System.Web;
using System.Runtime.Serialization;

namespace SimpleWebHosting
{
    class Program
    {
        static void Main(string[] args)
        {
            RobustOpenandCloseWeb();
            //DontDoThis();
            //RobustOpenandClose();
        }
        static void RobustOpenandCloseWeb()
        {
            ServiceHost sh =
              new WebServiceHost(typeof(HostingExample));//,      new Uri("http://localhost:8080/Hosting"));
            ServiceDebugBehavior debugB = null;
            debugB = sh.Description.Behaviors.Find<ServiceDebugBehavior>();
            if (debugB == null)
            {
                debugB = new ServiceDebugBehavior();
                sh.Description.Behaviors.Add(debugB);
            }
            debugB.IncludeExceptionDetailInFaults = true;
            sh.Faulted += new EventHandler(sh_Faulted);
            bool openSucceeded = false;
            try
            {
                sh.Open();
                openSucceeded = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("ServiceHost failed to open {0}", ex.ToString());
            }
            finally
            {
                if (!openSucceeded)
                    sh.Abort();
            }
            if (sh.State == CommunicationState.Opened)
            {
                Console.WriteLine("Service is running...");
                Console.ReadLine();
            }
            else
                Console.WriteLine("Service failed to open");
            bool closeSucceeded = false;
            try
            {
                sh.Close();
                closeSucceeded = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("ServiceHost failed to close {0}", ex.ToString());
            }
            finally
            {
                if (!closeSucceeded)
                    sh.Abort();
            }
        }

        static void sh_Faulted(object sender, EventArgs e)
        {
            
        }
        static void DontDoThis()
        {
            try
            {
                //DON'T DO THIS - THIS IS AN EXAMPLE OF BAD CODE!!!!!
                using (ServiceHost sh =
                    new ServiceHost(typeof(HostingExample)))
                {

                    ServiceEndpoint se = sh.AddServiceEndpoint(typeof(HostingExample),
                                            new WebHttpBinding(),
                                            "http://localhost:8080/Hosting");
                    se.Behaviors.Add(new WebHttpBehavior());
                    //what if call to Open fails?  We move to Faulted
                    sh.Open();
                    //This code never executes
                    Console.WriteLine("Service is running...");
                    Console.ReadLine();
                    sh.Close();
                    //when the using block exits,
                    //IDisposable.Dispose will be called
                    //ServiceHostBase.Dispose calls Close
                    //Calling Close on a Faulted object causes
                    //an exception to be thrown
                }
            }
            catch (Exception ex)
            {
                //this will be the wrong exception - the one that caused
                //ServiceHost.Open will be lost
                Console.WriteLine("Service host didn't open {0}", ex.Message);
            }
        }
        static void UnRobust()
        {
            //pass in a base address
            ServiceHost sh =
                new ServiceHost(typeof(HostingExample),
                    new Uri("http://localhost:8080/"));
            ServiceEndpoint se = sh.AddServiceEndpoint(typeof(HostingExample),
                                    new WebHttpBinding(),
                                    "Hosting");//Hosting will be added to base address
            se.Behaviors.Add(new WebHttpBehavior());
            sh.Open();
            Console.WriteLine("Service is running...");
            Console.ReadLine();
            sh.Abort();
            sh.Close();
        }
        static void RobustOpenandClose()
        {
            ServiceHost sh =
              new ServiceHost(typeof(HostingExample));
            bool openSucceeded = false;
            try
            {
                ServiceEndpoint se = sh.AddServiceEndpoint(typeof(HostingExample),
                           new WebHttpBinding(),
                           "http://localhost:8080/Hosting");
                se.Behaviors.Add(new WebHttpBehavior());
                sh.Open();
                openSucceeded = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("ServiceHost failed to open {0}", ex.ToString());
            }
            finally
            {
                if (!openSucceeded)
                    sh.Abort();
            }
            if (sh.State == CommunicationState.Opened)
            {
                Console.WriteLine("Service is running...");
                Console.ReadLine();
            }
            else
                Console.WriteLine("Service failed to open");
            bool closeSucceeded = false;
            try
            {
                sh.Close();
                closeSucceeded = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("ServiceHost failed to close {0}", ex.ToString());
            }
            finally
            {
                if (!closeSucceeded)
                    sh.Abort();
            }
        }
    }
    
    [ServiceContract()]
    [ServiceBehavior(InstanceContextMode=InstanceContextMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class HostingExample : IDisposable
    {
        [OperationContract]
        [WebGet(UriTemplate = "/")]
        public string TheMethod()
        {
            string ret = "Just testing service hosting ";
            if (HttpContext.Current != null)
                ret += " and HttpContext.Current isn't null!!!";
            return ret;
        }
        [OperationContract]
        [WebGet(UriTemplate = "/Divide?x={x}&y={y}")]
        public int FindCurrentPrice(string x,string y)
        {
            int realX = Int32.Parse(x);
            int realY = Int32.Parse(y);
            if (realY <= 0)
                throw new FaultException("Can't divde by zero!");
            return realX / realY;

        }

        private bool SymbolNotFound(string symbol)
        {
            throw new NotImplementedException();
        }

        #region IDisposable Members

        public void Dispose()
        {
            
        }

        #endregion
    }
    [DataContract(Namespace="")]
    public class StockQuote
    {
        [DataMember]
        public string Symbol;
        [DataMember]
        public decimal CurrentPrice;
    }

public class SafeCloseWebServiceHost : WebServiceHost
{
    public SafeCloseWebServiceHost(Type t, params Uri[] baseAddys)
        : base(t, baseAddys)
    {

    }
    public bool SafeOpen()
    {
        bool openSucceeded = false;
        try
        {
            this.Open();
            openSucceeded = true;
        }
        catch (Exception ex)
        {
            Console.WriteLine("ServiceHost failed to open {0}", ex.ToString());
        }
        finally
        {
            if (!openSucceeded)
                this.Abort();
        }
        if (this.State == CommunicationState.Opened)
        {
            Console.WriteLine("Service is running...");
            Console.ReadLine();
        }
        else
            Console.WriteLine("Service failed to open");
        return openSucceeded;
    }
    public bool SafeClose()
    {
        bool closeSucceeded = false;
        try
        {
            this.Close();
            closeSucceeded = true;
        }
        catch (Exception ex)
        {
            Console.WriteLine("ServiceHost failed to close nicely {0}", ex.ToString());
        }
        finally
        {
            if (!closeSucceeded)
                this.Abort();
        }
        return closeSucceeded;
    }
}
}
