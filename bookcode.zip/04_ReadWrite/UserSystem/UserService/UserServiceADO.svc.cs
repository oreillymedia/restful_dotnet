﻿using System;
using System.Collections.Generic;
using System.Data.Services;
using System.Linq;
using System.ServiceModel.Web;
using System.Web;
using UserDBModel;
using System.ServiceModel;
using System.Linq.Expressions;

namespace UserService
{
    public class UserService : DataService<UserDataContext>
    {
        public static void InitializeService(
                    IDataServiceConfiguration config)
        {
            config.SetEntitySetAccessRule("*", EntitySetRights.All);
            //config.SetEntitySetAccessRule("group", EntitySetRights.AllRead);
            config.SetServiceOperationAccessRule("admins", ServiceOperationRights.AllRead);
        }
        //[ChangeInterceptor("user")]
        //public void OnChangeUser(user u, UpdateOperations operation)
        //{

        //}
        //[QueryInterceptor("user")]
        //public Expression<Func<user, bool>> InterceptQuery()
        //s{
        //    return u => !String.IsNullOrEmpty(u.user_email);
        //}
        [WebGet()]
        public IQueryable<user> admins()
        {
            var result = from gm in this.CurrentDataSource.user_group_mapping
                         where gm.@group.group_name == "Admin"
                         select gm.user;
            return result;
        }
    }
}
