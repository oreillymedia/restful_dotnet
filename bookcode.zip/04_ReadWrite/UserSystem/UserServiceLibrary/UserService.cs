﻿//#define HTTP
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Net;

namespace UserServiceLibrary
{
    [ServiceContract]
    public class UserService
    {
        static Users _users = new Users();

        [WebGet(UriTemplate = "/users")]
        [OperationContract]
        public Users GetAllUsers()
        {

            return _users;
        }
        [WebInvoke(UriTemplate = "/users", Method = "POST")]
        [OperationContract]
        public User AddNewUser(User u)
        {
            u.UserId = Guid.NewGuid().ToString();
            u.LastModified = DateTimeOffset.Now;

            _users.Add(u);
            return u;
        }
      

       
        [WebGet(UriTemplate = "/users/{user_id}")]
        [OperationContract]
        public User GetUser(string user_id)
        {
            User u = FindUser(user_id);

            return u;
        }

       
        User FindUser(string user_id)
        {
            User ret = null;
            if (_users.Count > 0)
            {
                var result = (from u in _users
                              where u.UserId == user_id
                              select u);
                if (result != null)
                    ret = result.Single();
            }

            return ret;

        }
        [WebInvoke(UriTemplate = "/users/{user_id}", Method = "PUT")]
        [OperationContract]
        public User UpdateUser(string user_id, User update)
        {
            User u = FindUser(user_id);
            UpdateUserInternal(u, update);
            return u;
        }

        private void UpdateUserInternal(User u, User update)
        {
            u.Email = update.Email;
            u.FirstName = update.FirstName;
            u.LastName = update.LastName;

        }
        [WebInvoke(UriTemplate = "/users/{user_id}", Method = "DELETE")]
        [OperationContract]
        public void DeleteUser(string user_id)
        {
            User u = FindUser(user_id);
            _users.Remove(u);

        }
    }
  
    [CollectionDataContract(Name = "users", Namespace = "")]
    public class Users : List<User>
    {
    }
    [DataContract(Name = "user", Namespace = "")]
    public class User
    {
        [DataMember(Name = "id", Order = 1)]
        public string UserId;
        [DataMember(Name = "firstname", Order = 2)]
        public string FirstName;
        [DataMember(Name = "lastname", Order = 3)]
        public string LastName;
        [DataMember(Name = "email", Order = 4)]
        public string Email;
        public DateTimeOffset LastModified;
    }
    [DataContract(Name = "group", Namespace = "")]
    public class Group
    {
        [DataMember(Name = "name")]
        public string Name;
        [DataMember]
        public Users Users;

    }
}
