﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UserDBModel;
using System.Data.Services.Client;

namespace Populate
{
    class Program
    {
        static void Main(string[] args)
        {
Uri uri = 
    new Uri("http://win2008/UserService/UserService.svc/");
UserDBEntities db = new UserDBEntities(uri);
user u = new user();
u.user_email = "jon.flander@gmail.com";
u.user_first_name = "Jon";
u.user_last_name = "Flanders";
u.user_last_modified = DateTime.Now;
db.AddTouser(u);
db.SaveChanges();
        }
    }
}
