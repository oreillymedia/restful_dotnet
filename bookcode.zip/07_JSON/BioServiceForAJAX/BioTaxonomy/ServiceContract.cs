﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using System.ServiceModel.Channels;
using System.Xml.Serialization;

namespace BioTaxonomy
{
    [ServiceContract]
    public interface IBioTaxLitService
    {
        [OperationContract]
        [WebInvoke()]
        [WebGet(UriTemplate = "/Animalia")]
        Message ProcessAnimalia();
        [OperationContract]
        [WebGet(UriTemplate = "/Animalia/{Kingdom}")]
        Message ProcessAnimaliaKingdoms(string Kingdom);
        //other method omitted
    }
    [ServiceContract]
    public interface IBioTaxService
    {

//XML responses
[OperationContract]
[WebGet(UriTemplate = "/",ResponseFormat=WebMessageFormat.Xml)]
DomainList GetRoot();
[OperationContract]
[WebGet(UriTemplate = "/{Domain}", ResponseFormat = WebMessageFormat.Xml)]
KingdomList GetDomain(string Domain);
//JSON responses
[OperationContract]
[WebGet(UriTemplate = "/json", ResponseFormat = WebMessageFormat.Json)]
DomainList GetRootJSON();
[OperationContract]
[WebGet(UriTemplate = "/{Domain}/json", ResponseFormat = WebMessageFormat.Json)]
KingdomList GetDomainJSON(string Domain);
        //Message version
        //[OperationContract]
        //[WebGet(UriTemplate = "/")]
        //Message GetRoot();
        //[OperationContract]
        //[WebGet(UriTemplate = "/{Domain}")]
        //Message GetDomain(string Domain);
        //[OperationContract]
        //[WebGet(UriTemplate = "/{Domain}/{Kingdom}")]
        //Message GetKingdom(string Domain, string Kingdom);
        //[OperationContract]
        //[WebGet(UriTemplate = "/{Domain}/{Kingdom}/{Phylum}")]
        //Message GetPhylum(string Domain, string Kingdom, string Phylum);
        //[OperationContract]
        //[WebGet(UriTemplate = "/{Domain}/{Kingdom}/{Phylum}/{Class}")]
        //Message GetClass(string Domain, string Kingdom, string Phylum, string Class);
        //[OperationContract]
        //[WebGet(UriTemplate = "/{Domain}/{Kingdom}/{Phylum}/{Class}/{Order}")]
        //Message GetOrder(string Domain, string Kingdom, string Phylum, string Class, string Order);
        //[OperationContract]
        //[WebGet(UriTemplate = "/{Domain}/{Kingdom}/{Phylum}/{Class}/{Order}/{Family}")]
        //Message GetFamily(string Domain, string Kingdom, string Phylum, string Class, string Order, string Family);
        //[OperationContract]
        //[WebGet(UriTemplate = "/{Domain}/{Kingdom}/{Phylum}/{Class}/{Order}/{Family}/{Genus}")]
        //Message GetGenus(string Domain, string Kingdom, string Phylum, string Class, string Order, string Family, string Genus);
        //[OperationContract]
        //[WebGet(UriTemplate = "/{Domain}/{Kingdom}/{Phylum}/{Class}/{Order}/{Family}/{Genus}/{Species}")]
        //Message GetSpecies(string Domain, string Kingdom, string Phylum, string Class, string Order, string Family, string Genus, string Species);
    }
//[XmlRoot(Namespace="",ElementName="Domain")]
//public class Domain
//{
//   [XmlAttribute(AttributeName="name")]
//    public string Name;
//   [XmlAttribute(AttributeName = "uri")]       
//    public string Uri;
//}
//[XmlRoot(Namespace = "", ElementName = "Domains")]
//public class DomainList : List<Domain>
//{
//}
    [DataContract(Namespace = "")]
    public class Domain
    {
        [DataMember]
        public string Name;
        [DataMember]
        public string Uri;
    }
    [CollectionDataContract(Name = "Domains", Namespace = "")]
    public class DomainList : List<Domain>
    {
    }
    [DataContract(Namespace = "")]
    public class Kingdom
    {
        [DataMember]
        public string Name;
        [DataMember]
        public string Uri;
    }
    [CollectionDataContract(Name = "Kingdoms", Namespace = "")]
    public class KingdomList : List<Kingdom>
    {
    }
}
//[ServiceContract]
//public interface ICalculator
//{
//    [OperationContract]
//    [WebGet(UriTemplate = "/Add?x={x}&y={y}")]
//    int Add(int x, int y);
//    [OperationContract]
//    [WebGet(UriTemplate = "/Add/{x}/{y}")]
//    int Add(int x, int y);
//}
