﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Description;
using System.ServiceModel.Channels;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Runtime.Serialization.Json;

namespace BioTaxonomy
{
    public class BioTaxService : IBioTaxService
    {
        public DomainList GetRoot()
        {
            DomainList list = new DomainList();
            string[] domains = new string[] { "Archaea", "Eubacteria", "Eukaryota" };
            foreach (string domain in domains)
            {
                list.Add(new Domain { Name = domain, Uri = domain });

            }
            return list;
        }

        public KingdomList GetDomain(string Domain)
        {
            KingdomList list = new KingdomList();
            switch (Domain)
            {
                case "Eukaryota":
                    string[] kingdoms = new string[] { "Animalia", "Fungi", "Amoebozoa", "Plantae", "Chromalveolata", "Rhizaria", "Excavata" };
                    list.AddRange((from s in kingdoms
                                   select new Kingdom { Name = s, Uri = s }));
                    break;
                default:
                    break;
            }
            return list;
        }
        public DomainList GetRootJSON()
        {
            return GetRoot();
        }

        public KingdomList GetDomainJSON(string Domain)
        {
            return GetDomain(Domain);
        }
        #region IBioTaxService Members
////"loosely" typed top-level method
//public Message GetRoot()
//{
//    DomainList list = new DomainList();
//    string[] domains = new string[] { "Archaea", "Eubacteria", "Eukaryota" };
//    foreach (string domain in domains)
//    {
//        list.Add(new Domain { Name = domain, Uri = domain });

//    }
//    Message ret = CreateMessage(list);
//    return ret;
//}
////"loosely" typed method to get Kingdoms
//public Message GetDomain(string Domain)
//{
//    KingdomList list = new KingdomList();
//    switch (Domain)
//    {
//        case "Eukaryota":
//            string[] kingdoms = new string[] { "Animalia", "Fungi", "Amoebozoa", "Plantae", "Chromalveolata", "Rhizaria", "Excavata" };
//            list.AddRange((from s in kingdoms
//                           select new Kingdom { Name = s, Uri = s }));
//            break;
//        default:
//            break;
//    }
//    Message ret = CreateMessage(list);
//    return ret;
//}
//method to create Message object
Message CreateMessage(object msg)
{
    //find the right serializer
    XmlObjectSerializer serializer = SetSerializer(msg);
    //create the message
    Message ret = Message.CreateMessage(MessageVersion.None,
                                     "*",
                                        msg, serializer);
    return ret;

}
//method that looks at the accept header to 
//determine the right serializer
XmlObjectSerializer SetSerializer(object msg)
{
    XmlObjectSerializer ret = null;
    if (WebOperationContext.Current.IncomingRequest.Accept == "application/json")
    {
        //setup the right formatter for the message
        WebBodyFormatMessageProperty formatter = 
            new WebBodyFormatMessageProperty(WebContentFormat.Json);
        OperationContext.Current.OutgoingMessageProperties.Add(
            WebBodyFormatMessageProperty.Name, 
            formatter);
        //set the right content-type header
        WebOperationContext.Current.OutgoingResponse.ContentType = "application/json";
        //create the right serializer
        ret = new DataContractJsonSerializer(msg.GetType());
    }
    else
    {
        //create the normal XML serializer
        ret = new DataContractSerializer(msg.GetType());
    }
    return ret;
}
        public System.ServiceModel.Channels.Message GetKingdom(string Domain, string Kingdom)
        {
            throw new NotImplementedException();
        }

        public System.ServiceModel.Channels.Message GetPhylum(string Domain, string Kingdom, string Phylum)
        {
            throw new NotImplementedException();
        }

        public System.ServiceModel.Channels.Message GetClass(string Domain, string Kingdom, string Phylum, string Class)
        {
            throw new NotImplementedException();
        }

        public System.ServiceModel.Channels.Message GetOrder(string Domain, string Kingdom, string Phylum, string Class, string Order)
        {
            throw new NotImplementedException();
        }

        public System.ServiceModel.Channels.Message GetFamily(string Domain, string Kingdom, string Phylum, string Class, string Order, string Family)
        {
            throw new NotImplementedException();
        }

        public System.ServiceModel.Channels.Message GetGenus(string Domain, string Kingdom, string Phylum, string Class, string Order, string Family, string Genus)
        {
            throw new NotImplementedException();
        }

        public System.ServiceModel.Channels.Message GetSpecies(string Domain, string Kingdom, string Phylum, string Class, string Order, string Family, string Genus, string Species)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
    public class XmlOrJsonWebHttpBehavior : WebHttpBehavior
    {
        public override void ApplyDispatchBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.EndpointDispatcher endpointDispatcher)
        {
            base.ApplyDispatchBehavior(endpoint, endpointDispatcher);
            //fixup the Formatter
        }
        //TODO: For client side
        public override void ApplyClientBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.ClientRuntime clientRuntime)
        {
            base.ApplyClientBehavior(endpoint, clientRuntime);
        }
    }
    public class ContentTypeFormatter : IDispatchMessageFormatter
    {

        public void DeserializeRequest(Message message, object[] parameters)
        {

        }

        public Message SerializeReply(MessageVersion messageVersion, object[] parameters, object result)
        {
            return null;
        }

    }
}
