﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.ServiceModel;
using BioTaxonomy;
using System.ServiceModel.Web;

[ServiceContract(Namespace="")]
public class BioWrapper
{
    [OperationContract()]
    [WebGet()]
    public DomainList GetRoot()
    {
        BioTaxService realImpl = new BioTaxService();
        return realImpl.GetRoot();
    }
    [OperationContract()]
    [WebGet()]
    public KingdomList GetDomain(string Domain)
    {
        BioTaxService realImpl = new BioTaxService();
        return realImpl.GetDomain(Domain);
    }
    //other methods excluded for clarity
    
}
