﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Web;
using BioTaxonomy;
using System.ServiceModel.Channels;
using System.Xml;
using System.IO;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

namespace Service
{
    class Program
    {
        static void Main(string[] args)
        {
            WebServiceHost sh = new WebServiceHost(typeof(BioTaxService));
            ServiceEndpoint se = sh.AddServiceEndpoint(typeof(IBioTaxService), new WebHttpBinding(), "http://localhost/BioService/");
            //se.Behaviors.Add(new WebScriptEnablingBehavior());
            sh.Open();
            Console.WriteLine("Service up and running...");
            Console.ReadLine();
        }

    }


}
