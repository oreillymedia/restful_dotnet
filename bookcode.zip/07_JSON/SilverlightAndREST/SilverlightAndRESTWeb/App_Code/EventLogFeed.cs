﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.ServiceModel.Syndication;
using System.Diagnostics;
using System.Collections.Generic;

public class EventLogFeed : IEventLogFeed
{

    public Rss20FeedFormatter GetRSS(string log)
    {
        SyndicationFeed feed = GetFeed(log);
        Rss20FeedFormatter formatter = new Rss20FeedFormatter(feed);
        return formatter;
    }

    public Atom10FeedFormatter GetAtom(string log)
    {
        SyndicationFeed feed = GetFeed(log);
        Atom10FeedFormatter formatter = new Atom10FeedFormatter(feed);
        return formatter;
    }

    private SyndicationFeed GetFeed(string logName)
    {
        EventLog el = new EventLog(logName);
        SyndicationFeed feed = new SyndicationFeed();
        feed.Title =
            new TextSyndicationContent(String.Format("{0} {1} EventLog Feed",
                Environment.MachineName,
                el.Log));
        feed.Description = new TextSyndicationContent("A feed of data from the EventLog");
        feed.Authors.Add(new SyndicationPerson { Name = Environment.MachineName });
        feed.Id = "urn:uuid:" + Guid.NewGuid().ToString();
        //the Uri being requested
        Uri u = WebOperationContext.Current.IncomingRequest.UriTemplateMatch.RequestUri;
        feed.BaseUri = u;
        //use the factory method to create a self link
        //  feed.Links.Add(SyndicationLink.CreateSelfLink(u));
        feed.Links.Add(SyndicationLink.CreateSelfLink(new Uri("", UriKind.Relative)));//, "application/atom+xml"));

        //assume aspx page with same name
        string aspxUri = u.AbsoluteUri.Replace(u.AbsoluteUri.Contains(".atom") ? "atom" : "rss", "aspx");
        Uri nu = new Uri(aspxUri);
        //create the alternate link
        feed.Links.Add(SyndicationLink.CreateAlternateLink(nu, "text/html"));
        List<SyndicationItem> items = new List<SyndicationItem>();
        feed.Items = items;

        foreach (EventLogEntry e in el.Entries)
        {
            items.Add(new SyndicationItem
            {
                Title = new TextSyndicationContent(String.Format("{0}:{1}:{2}", e.Source, e.Category, e.EntryType.ToString())),
                Content = new TextSyndicationContent(e.Message),
                PublishDate = new DateTimeOffset(e.TimeGenerated),
                LastUpdatedTime = new DateTimeOffset(e.TimeGenerated),
                Id = "urn:uuid:" + Guid.NewGuid().ToString()

            });

        }
        return feed;
    }
}
[ServiceContract]
public interface IEventLogFeed
{
    [OperationContract]
    [WebGet(UriTemplate = "/{log}/feed/rss")]
    Rss20FeedFormatter GetRSS(string log);
    [OperationContract]
    [WebGet(UriTemplate = "/{log}/feed/atom")]
    Atom10FeedFormatter GetAtom(string log);
}
