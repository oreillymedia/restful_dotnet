﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Json;
using System.ServiceModel.Syndication;

namespace SilverlightAndREST
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();
        }

        private void _reader_Click(object sender, RoutedEventArgs e)
        {
            _currentMode = Mode.XmlReader;
            DoRest();
        }
        string _baseUri = "http://localhost:51435/SilverlightAndRESTWeb/BioService.svc/";
private void DoRest()
{
    _domainsListBox.DataContext = null;
    _kingdomsListBox.DataContext = null;
    WebClient c = new WebClient();
    c.OpenReadCompleted += DomainComplete;
    c.OpenReadAsync(new Uri(_baseUri));
}

void DomainComplete(object sender,
    OpenReadCompletedEventArgs e)
{
    Stream streamResult = e.Result;

    switch (_currentMode)
    {
        case Mode.XmlReader:
            WriteDomainsXmlReader(streamResult);
            break;
        case Mode.LinqToXML:
            WriteDomainsLinqToXML(streamResult);
            break;
        case Mode.XMlSerializer:
            WriteDomainsXmlSerializer(streamResult);
            break;
        default:
            break;
    }

}
        XmlSerializer _domainSerializer = new XmlSerializer(typeof(Domains));
        XmlSerializer _kingdomSerializer = new XmlSerializer(typeof(Kingdoms));

private void WriteDomainsXmlSerializer(Stream streamResult)
{
    Domains domains = (Domains)_domainSerializer.Deserialize(streamResult);
    var results = from domain in domains.Domain
                  select new BindingClass { Text = domain.Uri };
    _domainsListBox.DataContext = results;

}
private void WriteKingdomsXmlSerializer(Stream streamResult)
{
    Kingdoms kingdoms = (Kingdoms)_kingdomSerializer.Deserialize(streamResult);
    var results = from kingdom in kingdoms.Items
                  select new BindingClass { Text = kingdom.Uri };
    _kingdomsListBox.DataContext = results;

}

private void WriteDomainsLinqToXML(Stream streamResult)
{
    XDocument xd =
        XDocument.Load(XmlReader.Create(streamResult));
    var results = from uris in xd.Descendants("Uri")
                  select new BindingClass { Text = uris.Value };

    _domainsListBox.DataContext = results;
}

private void WriteDomainsXmlReader(Stream streamResult)
{
    //create the collection for data binding
    List<BindingClass> bindingContext =
        new List<BindingClass>();
    string uri = null;
    //parse the result stream to an XmlReader
    using (XmlReader xr = XmlReader.Create(streamResult))
    {
        xr.MoveToContent();
        xr.Read();//Move past Domains
        while (xr.Read())
        {
            //pull the Uri result
            if (xr.Name == "Uri" &&
                xr.NodeType == XmlNodeType.Element)
            {
                //read out the value of the Uri element
                uri = xr.ReadElementContentAsString();
                //add a new Binding class - reading out the value of the Uri element
                bindingContext.Add(new BindingClass { Text = uri });
            }
        }
    }
    //give the collection to the ListBox for data binding
    _domainsListBox.DataContext = bindingContext;
}

        private void _linq_Click(object sender, RoutedEventArgs e)
        {
            _currentMode = Mode.LinqToXML;
            DoRest();
        }

        private void _serialization_Click(object sender, RoutedEventArgs e)
        {
            _currentMode = Mode.XMlSerializer;
            DoRest();
        }
        Mode _currentMode;
        private void _domain_Click(object sender, RoutedEventArgs e)
        {
            HyperlinkButton button = sender as HyperlinkButton;
            TextBlock text = button.Content as TextBlock;
            string domain = text.Text;
            ProcessDomain(domain);
        }

        private void ProcessDomain(string domain)
        {

            WebClient c = new WebClient();
            c.OpenReadCompleted += KingdomComplete;
            c.OpenReadAsync(new Uri(_baseUri + domain));
        }
        void KingdomComplete(object sender,
           OpenReadCompletedEventArgs e)
        {
            Stream streamResult = e.Result;

            switch (_currentMode)
            {
                case Mode.XmlReader:
                    WriteKingdomsXmlReader(streamResult);
                    break;
                case Mode.LinqToXML:
                    WriteKingdomsLinqToXML(streamResult);
                    break;
                case Mode.XMlSerializer:
                    WriteKingdomsXmlSerializer(streamResult);
                    break;
                default:
                    break;
            }
        }

        private void WriteKingdomsLinqToXML(Stream streamResult)
        {
            XDocument xd =
               XDocument.Load(XmlReader.Create(streamResult));
            var results = from uris in xd.Descendants("Uri")
                          select new BindingClass { Text = uris.Value };

            _kingdomsListBox.DataContext = results;
        }
        private void WriteKingdomsXmlReader(Stream streamResult)
        {
            List<BindingClass> bindingContext = new List<BindingClass>();
            using (XmlReader xr = XmlReader.Create(streamResult))
            {
                xr.MoveToContent();
                xr.Read();//Move past Domains
                while (xr.Read())
                {
                    if (xr.Name == "Uri" &&
                        xr.NodeType == XmlNodeType.Element)
                    {
                        bindingContext.Add(new BindingClass { Text = xr.ReadElementContentAsString() });
                    }
                }
            }
            _kingdomsListBox.DataContext = bindingContext;
        }

        private void _kingdom_Click(object sender, RoutedEventArgs e)
        {

        }

        private void _json_Click(object sender, RoutedEventArgs e)
        {
            _domainsListBoxJSON.DataContext = null;
            _kingdomsListBoxJSON.DataContext = null;
            WebClient c = new WebClient();
            //this doesn't work
            c.Headers[HttpRequestHeader.Accept] = "application/json";
            c.OpenReadCompleted += DomainCompleteJson;
            c.OpenReadAsync(new Uri(_baseUri + "json"));

        }
//event handler for JSON button
private void _domainJSON_Click(object sender, RoutedEventArgs e)
{

    HyperlinkButton button = sender as HyperlinkButton;
    TextBlock text = button.Content as TextBlock;
    string domain = text.Text;
    ProcessDomainJSON(domain);
}
//WebClient call for JSON
private void ProcessDomainJSON(string domain)
{
    WebClient c = new WebClient();
    c.OpenReadCompleted += KingdomCompleteJSON;
    c.OpenReadAsync(new Uri(_baseUri + domain + "/json"));
}
//Complete event handler for JSON
void DomainCompleteJson(object sender,
   OpenReadCompletedEventArgs e)
{
    Stream streamResult = e.Result;
    JsonArray json = (JsonArray)JsonObject.Load(streamResult);
    var result = from j in json
                 select new BindingClass { Text = j["Uri"] };
    _domainsListBoxJSON.DataContext = result;
}


 
        void KingdomCompleteJSON(object sender,
         OpenReadCompletedEventArgs e)
        {
            Stream streamResult = e.Result;
            JsonArray json = (JsonArray)JsonObject.Load(streamResult);
            var result = from j in json
                         select new BindingClass { Text = j["Uri"] };
            _kingdomsListBoxJSON.DataContext = result;

        }
        string _feedUri = "http://localhost:51435/SilverlightAndRESTWeb/EventLogFeed.svc/application/feed/atom";
//event handler for button
private void _feed_Click(object sender, RoutedEventArgs e)
{
    WebClient c = new WebClient();
    c.OpenReadCompleted += FeeComplete;
    c.OpenReadAsync(new Uri(_feedUri));
    //c.OpenWriteCompleted += new OpenWriteCompletedEventHandler(c_OpenWriteCompleted);
    //c.OpenWriteAsync(new Uri(_feedUri));
}

void c_OpenWriteCompleted(object sender, OpenWriteCompletedEventArgs e)
{
    
}
//called when feed is delivered
void FeeComplete(object sender,
OpenReadCompletedEventArgs e)
{
    Stream streamResult = e.Result;
    XmlReader xr = XmlReader.Create(streamResult);
    SyndicationFeed feed =
        SyndicationFeed.Load(xr);
    var result = from item in feed.Items
                 select new BindingClass 
                 {
                     Text = 
                     ((TextSyndicationContent)item.Content).Text
                 };
    _feedListBox.DataContext = result;
}

    }
    public enum Mode
    {
        XmlReader,
        LinqToXML,
        XMlSerializer
    }
    public class BindingClass
    {
        public string Text { get; set; }
    }
}
