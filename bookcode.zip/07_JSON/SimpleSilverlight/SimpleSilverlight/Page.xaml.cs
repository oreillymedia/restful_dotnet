﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;

namespace SimpleSilverlight
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();
        }
        string _uri = "http://localhost:58814/SimpleService.svc/";
    private void _getData_Click(object sender, RoutedEventArgs e)
    {
        WebClient wc = new WebClient();
        wc.DownloadStringCompleted +=delegate(object o,DownloadStringCompletedEventArgs args)
        {
            _result.Text = args.Result;

        };
        wc.DownloadStringAsync(new Uri(_uri));



    }

    private void _setData_Click(object sender, RoutedEventArgs e)
    {
        WebClient wc = new WebClient();
        //wc.OpenWriteCompleted += delegate(object o, OpenWriteCompletedEventArgs args)
        //{
        //    _result.Text = new StreamReader(args.Result).ReadToEnd();
        //};
        //wc.OpenWriteAsync(new Uri(_uri+ "update"));
        wc.UploadStringCompleted += delegate(object o, UploadStringCompletedEventArgs  args)
        {
            _result.Text = args.Result;
        };
        wc.Headers[HttpRequestHeader.ContentType] = "text/xml";
        //wc.UploadStringAsync(new Uri(_uri + "update"),String.Format("<string xmlns=\"http://schemas.microsoft.com/2003/10/Serialization/\">{0}</string>", _newData.Text));
    }
    }
}
