﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading;

namespace SimpleSilverlightWeb
{
    // NOTE: If you change the class name "SimpleService" here, you must also update the reference to "SimpleService" in Web.config.
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class SimpleService : ISimpleService
    {
        string _data = "Simple Silverlight Test";
        public string Simple()
        {
            Thread.Sleep(2000);
            return _data;
        }





        public string SimpleUpdate(string newString)
        {
            _data = newString;
            return _data;
        }


    }
}
