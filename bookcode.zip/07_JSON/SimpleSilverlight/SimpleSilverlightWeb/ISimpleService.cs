﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;

namespace SimpleSilverlightWeb
{
    // NOTE: If you change the interface name "ISimpleService" here, you must also update the reference to "ISimpleService" in Web.config.
    [ServiceContract]
    public interface ISimpleService
    {
        [OperationContract]
        [WebGet(UriTemplate="/")]
        string Simple();
        [OperationContract]
        [WebInvoke(UriTemplate = "/update")]
        string SimpleUpdate(string newString);
    }
}
