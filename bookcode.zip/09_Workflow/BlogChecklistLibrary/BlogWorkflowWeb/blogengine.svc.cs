﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using BlogCheckListContracts;
using System.ServiceModel.Syndication;

namespace BlogWorkflowWeb
{
    [ServiceBehavior(InstanceContextMode=InstanceContextMode.Single)]
    public class blogengine : IBlogAPI
    {

        List<SyndicationItem> _entries = new List<SyndicationItem>();

        public Atom10ItemFormatter AddEntry(Atom10ItemFormatter entry)
        {
            entry.Item.Id = Guid.NewGuid().ToString();
            _entries.Add(entry.Item);
            return entry;
        }


      


        public Atom10FeedFormatter GetBlog()
        {
            SyndicationFeed feed = new SyndicationFeed();
            feed.Title = new TextSyndicationContent("Workflow sample feed");
            feed.Items = _entries;
            Atom10FeedFormatter feedFormatter = new Atom10FeedFormatter(feed);
            return feedFormatter;
            
        }



        #region IBlogAPI Members


        public Atom10ItemFormatter GetEntry(string id)
        {
            throw new NotImplementedException();
        }

        public Atom10ItemFormatter DeleteEntry(string id)
        {
            throw new NotImplementedException();
        }

        public Atom10ItemFormatter UpateEntry(string id)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IBlogAPI Members


        public Atom10ItemFormatter UpateEntry(string id, Atom10ItemFormatter entry)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
