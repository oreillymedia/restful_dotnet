﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Workflow.Runtime;
using System.ServiceModel.Syndication;
using System.Threading;
using System.Windows.Threading;
using System.Workflow.Runtime.Hosting;
using System.ServiceModel.Description;
using System.ServiceModel;
using BlogCheckListContracts;

namespace BlogEditClient
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }
//        static WorkflowRuntime _wr = InitRuntime();

//        private static WorkflowRuntime InitRuntime()
//        {
////create the workflow runtime
//WorkflowRuntime wr = new WorkflowRuntime();
//List<ServiceEndpoint> listOfEndpoints
//     = new List<ServiceEndpoint>();
////create the endpoint
//WebHttpBinding b = new WebHttpBinding();
//string uri = "http://localhost/BlogWorkflowWeb/blogengine.svc";
//ContractDescription cd = 
//    ContractDescription.GetContract(typeof(IBlogAPI));
//ServiceEndpoint webServiceEndpoint = 
//    new ServiceEndpoint(cd, b, new EndpointAddress(uri));
//webServiceEndpoint.Behaviors.Add(new WebHttpBehavior());
////make sure to name it correctly
//webServiceEndpoint.Name = "Web";
//listOfEndpoints.Add(webServiceEndpoint);
//ChannelManagerService cms = 
//    new ChannelManagerService(listOfEndpoints);
//wr.AddService(cms);
//wr.StartRuntime();
//            return wr;
//        }
//        static Type _workflowType = typeof(BlogChecklistLibrary.EntryChecklistWorkflow);

        IBlogApprovalAPI _channel = null;

        private static IBlogApprovalAPI InitChannel()
        {
            ChannelFactory<IBlogApprovalAPI>
                cf = new ChannelFactory<IBlogApprovalAPI>("StatefulWorkflow");
            return cf.CreateChannel();
        }
        string _currentId = null;
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            
            SyndicationItem item = new SyndicationItem();
            item.Title = new TextSyndicationContent(_title.Text);
            item.Content = new TextSyndicationContent(_entry.Text);
            item.LastUpdatedTime = DateTimeOffset.Now;
            Atom10ItemFormatter itemFormatter =
                new Atom10ItemFormatter(item);
            if (_currentId == null)
            {
                _channel = InitChannel();
                Atom10ItemFormatter newEntry = _channel.AddEntry(itemFormatter);
                _currentId = newEntry.Item.Id;
                string msg = "New entry added " + _currentId;
                updateResults(msg);
            }
            else
            {
                item.Id = _currentId;
                Atom10ItemFormatter newEntry = _channel.UpateEntry(_currentId,itemFormatter);
                
                string msg = "Entry updated " + _currentId;
                updateResults(msg);
            }
            //Dictionary<string, object> prms = new Dictionary<string, object>();
            //string prop = "Entry";
            //prms.Add(prop, item);
            //WorkflowInstance wi = 
            //    _wr.CreateWorkflow(_workflowType,prms);
            //EventHandler<WorkflowCompletedEventArgs> d = null;
            //d = delegate(object o, WorkflowCompletedEventArgs args)
            //{
            //    if (args.WorkflowInstance.InstanceId == wi.InstanceId)
            //    {
            //        SyndicationItem newEntry =
            //            args.OutputParameters[prop] as SyndicationItem;                    
            //        string msg = "New entry added " + newEntry.Id;
            //        Dispatcher.BeginInvoke(DispatcherPriority.Normal, 
            //            new Update(updateResults),
            //            msg);
                                    

            //        _wr.WorkflowCompleted -= d;
            //    }
            //};
            //_wr.WorkflowCompleted += d;
            //wi.Start();

        }
        void updateResults(string msg)
        {
            _result.Content = msg;

        }

        private void _approve_Click(object sender, RoutedEventArgs e)
        {
            SyndicationItem item = new SyndicationItem();
            item.Title = new TextSyndicationContent(_title.Text);
            item.Content = new TextSyndicationContent(_entry.Text);
            item.LastUpdatedTime = DateTimeOffset.Now;
            Atom10ItemFormatter itemFormatter =
                new Atom10ItemFormatter(item);
            Atom10ItemFormatter newEntry = _channel.ApproveEntry(_currentId, itemFormatter);
            _currentId = newEntry.Item.Id;
            string msg = "Entry Approved " + _currentId;
            //reset 
            _currentId = null;
            ((IClientChannel)_channel).Close();
            _channel = InitChannel();
            _title.Text = "";
            _entry.Text = "";
            updateResults(msg);
        }
    }
    public delegate void Update(string msg);
}
