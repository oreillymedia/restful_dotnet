﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Syndication;
using System.ServiceModel.Web;

namespace BlogCheckListContracts
{
    [ServiceContract(Namespace = "",
        SessionMode = SessionMode.NotAllowed)]
public interface IBlogAPI
{
    [OperationContract]
    [WebInvoke(UriTemplate = "/blog")]
    Atom10ItemFormatter AddEntry(Atom10ItemFormatter entry);
    [OperationContract]
    [WebGet(UriTemplate = "/blog")]
    Atom10FeedFormatter GetBlog();
    [OperationContract]
    [WebGet(UriTemplate = "/blog/{id}")]
    Atom10ItemFormatter GetEntry(string id);
    [OperationContract]
    [WebInvoke(UriTemplate = "/blog/{id}", Method = "DELETE")]
    Atom10ItemFormatter DeleteEntry(string id);
    [OperationContract]
    [WebInvoke(UriTemplate = "/blog/{id}", Method = "PUT")]
    Atom10ItemFormatter UpateEntry(string id,Atom10ItemFormatter entry);
}

[ServiceContract(Namespace = "")]
public interface IBlogApprovalAPI : IBlogAPI
{
    [OperationContract]
    [WebInvoke(UriTemplate = "/blog/{id}/approve",Method="PUT")]
    Atom10ItemFormatter ApproveEntry(string id,Atom10ItemFormatter entry);
}
}
