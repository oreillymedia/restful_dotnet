﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace BlogChecklistLibrary
{
	partial class EntryChecklistWorkflow
	{
		#region Designer generated code
		
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
            this.CanModifyActivities = true;
            System.Workflow.Activities.ChannelToken channeltoken1 = new System.Workflow.Activities.ChannelToken();
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding1 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding2 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo1 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
            this.sendBlogEntry = new System.Workflow.Activities.SendActivity();
            this.CreateAtom = new BlogChecklistLibrary.CreateAtomItemActivity();
            this.DoSpellCheck = new BlogChecklistLibrary.SpellCheckActivity();
            // 
            // sendBlogEntry
            // 
            channeltoken1.EndpointName = "Web";
            channeltoken1.Name = "MyRESTToken";
            this.sendBlogEntry.ChannelToken = channeltoken1;
            this.sendBlogEntry.Name = "sendBlogEntry";
            activitybind1.Name = "EntryChecklistWorkflow";
            activitybind1.Path = "_theEntry";
            workflowparameterbinding1.ParameterName = "entry";
            workflowparameterbinding1.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            activitybind2.Name = "EntryChecklistWorkflow";
            activitybind2.Path = "_theEntry";
            workflowparameterbinding2.ParameterName = "(ReturnValue)";
            workflowparameterbinding2.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
            this.sendBlogEntry.ParameterBindings.Add(workflowparameterbinding1);
            this.sendBlogEntry.ParameterBindings.Add(workflowparameterbinding2);
            typedoperationinfo1.ContractType = typeof(BlogCheckListContracts.IBlogAPI);
            typedoperationinfo1.Name = "AddEntry";
            this.sendBlogEntry.ServiceOperationInfo = typedoperationinfo1;
            this.sendBlogEntry.AfterResponse += new System.EventHandler<System.Workflow.Activities.SendActivityEventArgs>(this.sendActivity1_AfterResponse);
            this.sendBlogEntry.BeforeSend += new System.EventHandler<System.Workflow.Activities.SendActivityEventArgs>(this.sendActivity1_BeforeSend);
            // 
            // CreateAtom
            // 
            activitybind3.Name = "EntryChecklistWorkflow";
            activitybind3.Path = "_theEntry";
            this.CreateAtom.Name = "CreateAtom";
            activitybind4.Name = "EntryChecklistWorkflow";
            activitybind4.Path = "Entry";
            this.CreateAtom.SetBinding(BlogChecklistLibrary.CreateAtomItemActivity.AtomEntryProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
            this.CreateAtom.SetBinding(BlogChecklistLibrary.CreateAtomItemActivity.SyndicationItemProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
            // 
            // DoSpellCheck
            // 
            this.DoSpellCheck.Name = "DoSpellCheck";
            // 
            // EntryChecklistWorkflow
            // 
            this.Activities.Add(this.DoSpellCheck);
            this.Activities.Add(this.CreateAtom);
            this.Activities.Add(this.sendBlogEntry);
            this.Name = "EntryChecklistWorkflow";
            this.CanModifyActivities = false;

		}

		#endregion

        private CreateAtomItemActivity CreateAtom;
        private SpellCheckActivity DoSpellCheck;
        private SendActivity sendBlogEntry;


















    }
}
