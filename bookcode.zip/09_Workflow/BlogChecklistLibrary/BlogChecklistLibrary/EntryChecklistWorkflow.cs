﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.ServiceModel.Syndication;
namespace BlogChecklistLibrary
{
	public sealed partial class EntryChecklistWorkflow: SequentialWorkflowActivity
	{
		public EntryChecklistWorkflow()
		{
			InitializeComponent();
		}
        public SyndicationItem Entry { get; set; }
        public Atom10ItemFormatter _theEntry = new Atom10ItemFormatter();

        private void sendActivity1_AfterResponse(object sender, SendActivityEventArgs e)
        {
            this.Entry = this._theEntry.Item;
        }

        private void sendActivity1_BeforeSend(object sender, SendActivityEventArgs e)
        {

        }
	}

}
