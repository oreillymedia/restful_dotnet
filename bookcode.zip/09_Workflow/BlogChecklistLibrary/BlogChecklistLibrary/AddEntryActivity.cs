﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel;
using System.ServiceModel.Syndication;
using System.Workflow.Runtime;

namespace BlogChecklistLibrary
{
	public class AddEntryActivity : Activity
	{
        public static DependencyProperty EntryProperty = DependencyProperty.Register("Entry", typeof(Atom10ItemFormatter), typeof(AddEntryActivity));

        [System.ComponentModel.DescriptionAttribute("Entry")]
        [System.ComponentModel.CategoryAttribute("Entry Category")]
        [System.ComponentModel.BrowsableAttribute(true)]
        [System.ComponentModel.DesignerSerializationVisibilityAttribute(System.ComponentModel.DesignerSerializationVisibility.Visible)]
        public Atom10ItemFormatter Entry
        {
            get
            {
                return ((Atom10ItemFormatter)(base.GetValue(AddEntryActivity.EntryProperty)));
            }
            set
            {
                base.SetValue(AddEntryActivity.EntryProperty, value);
            }
        }
        protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
        {
            if (this.Entry != null)
            {
                this.Entry.Item.Id = WorkflowEnvironment.WorkflowInstanceId.ToString();
            }
            return ActivityExecutionStatus.Closed;
        }
	}
}
