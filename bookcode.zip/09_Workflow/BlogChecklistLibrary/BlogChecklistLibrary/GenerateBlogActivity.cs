﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel;
using System.ServiceModel.Syndication;

namespace BlogChecklistLibrary
{
	public class GenerateBlogActivity : Activity
	{
        public static DependencyProperty Atom10FeedProperty = DependencyProperty.Register("Atom10Feed", typeof(Atom10FeedFormatter), typeof(GenerateBlogActivity));

        [System.ComponentModel.DescriptionAttribute("Atom10Feed")]
        [System.ComponentModel.CategoryAttribute("Atom10Feed Category")]
        [System.ComponentModel.BrowsableAttribute(true)]
        [System.ComponentModel.DesignerSerializationVisibilityAttribute(System.ComponentModel.DesignerSerializationVisibility.Visible)]
        public Atom10FeedFormatter Atom10Feed
        {
            get
            {
                return ((Atom10FeedFormatter)(base.GetValue(GenerateBlogActivity.Atom10FeedProperty)));
            }
            set
            {
                base.SetValue(GenerateBlogActivity.Atom10FeedProperty, value);
            }
        }
        protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
        {
            SyndicationFeed feed = new SyndicationFeed();
            feed.Title = new TextSyndicationContent("Workflow sample feed");
            List<SyndicationItem> items = new List<SyndicationItem>();
            feed.Items = items;
            for (int i = 0; i < 10; i++)
            {
                items.Add( new SyndicationItem{
                Title= new TextSyndicationContent("Testing " + i.ToString()),
                Content = new TextSyndicationContent("Testing content " + i.ToString())
                });
            }
            Atom10FeedFormatter feedFormatter = new Atom10FeedFormatter(feed);
            this.Atom10Feed = feedFormatter;
             return ActivityExecutionStatus.Closed;
        }
	}
}
