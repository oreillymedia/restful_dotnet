﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel;
using System.ServiceModel.Syndication;
using System.Diagnostics;

namespace BlogChecklistLibrary
{
	public class ApproveEntryActivity : Activity
	{
        public static DependencyProperty EntryProperty = DependencyProperty.Register("Entry", typeof(Atom10ItemFormatter), typeof(ApproveEntryActivity));

        [System.ComponentModel.DescriptionAttribute("Entry")]
        [System.ComponentModel.CategoryAttribute("Entry Category")]
        [System.ComponentModel.BrowsableAttribute(true)]
        [System.ComponentModel.DesignerSerializationVisibilityAttribute(System.ComponentModel.DesignerSerializationVisibility.Visible)]
        public Atom10ItemFormatter Entry
        {
            get
            {
                return ((Atom10ItemFormatter)(base.GetValue(ApproveEntryActivity.EntryProperty)));
            }
            set
            {
                base.SetValue(ApproveEntryActivity.EntryProperty, value);
            }
        }
        protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
        {
            if (this.Entry != null)
            {
                Debug.WriteLine("Approved Entry " + this.Entry.Item.Id.ToString());
            }
            return ActivityExecutionStatus.Closed;
        }
	}
}
