﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace BlogChecklistLibrary
{
    partial class StateMachineBlogAPIService
    {
        #region Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
            this.CanModifyActivities = true;
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo1 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo2 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo3 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo4 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding1 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo5 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.Activities.WorkflowServiceAttributes workflowserviceattributes1 = new System.Workflow.Activities.WorkflowServiceAttributes();
            this.generateBlogActivity1 = new BlogChecklistLibrary.GenerateBlogActivity();
            this.setStateActivity5 = new System.Workflow.Activities.SetStateActivity();
            this.receiveActivity1 = new System.Workflow.Activities.ReceiveActivity();
            this.setStateActivity4 = new System.Workflow.Activities.SetStateActivity();
            this.receiveActivity4 = new System.Workflow.Activities.ReceiveActivity();
            this.setStateActivity3 = new System.Workflow.Activities.SetStateActivity();
            this.receiveActivity5 = new System.Workflow.Activities.ReceiveActivity();
            this.setStateActivity2 = new System.Workflow.Activities.SetStateActivity();
            this.receiveActivity3 = new System.Workflow.Activities.ReceiveActivity();
            this.setStateActivity1 = new System.Workflow.Activities.SetStateActivity();
            this.receiveActivity2 = new System.Workflow.Activities.ReceiveActivity();
            this.UpdateEntryEvent = new System.Workflow.Activities.EventDrivenActivity();
            this.DeleteEntryEvent = new System.Workflow.Activities.EventDrivenActivity();
            this.GetEntryEvent = new System.Workflow.Activities.EventDrivenActivity();
            this.AddEntryEvent = new System.Workflow.Activities.EventDrivenActivity();
            this.GetBlogEvent = new System.Workflow.Activities.EventDrivenActivity();
            this.Done = new System.Workflow.Activities.StateActivity();
            this.StateMachineBlogAPIServiceInitialState = new System.Workflow.Activities.StateActivity();
            // 
            // generateBlogActivity1
            // 
            this.generateBlogActivity1.Atom10Feed = null;
            this.generateBlogActivity1.Name = "generateBlogActivity1";
            // 
            // setStateActivity5
            // 
            this.setStateActivity5.Name = "setStateActivity5";
            this.setStateActivity5.TargetStateName = "Done";
            // 
            // receiveActivity1
            // 
            this.receiveActivity1.CanCreateInstance = true;
            this.receiveActivity1.Name = "receiveActivity1";
            typedoperationinfo1.ContractType = typeof(BlogCheckListContracts.IBlogAPI);
            typedoperationinfo1.Name = "UpateEntry";
            this.receiveActivity1.ServiceOperationInfo = typedoperationinfo1;
            // 
            // setStateActivity4
            // 
            this.setStateActivity4.Name = "setStateActivity4";
            this.setStateActivity4.TargetStateName = "Done";
            // 
            // receiveActivity4
            // 
            this.receiveActivity4.CanCreateInstance = true;
            this.receiveActivity4.Name = "receiveActivity4";
            typedoperationinfo2.ContractType = typeof(BlogCheckListContracts.IBlogAPI);
            typedoperationinfo2.Name = "DeleteEntry";
            this.receiveActivity4.ServiceOperationInfo = typedoperationinfo2;
            // 
            // setStateActivity3
            // 
            this.setStateActivity3.Name = "setStateActivity3";
            this.setStateActivity3.TargetStateName = "Done";
            // 
            // receiveActivity5
            // 
            this.receiveActivity5.CanCreateInstance = true;
            this.receiveActivity5.Name = "receiveActivity5";
            typedoperationinfo3.ContractType = typeof(BlogCheckListContracts.IBlogAPI);
            typedoperationinfo3.Name = "GetEntry";
            this.receiveActivity5.ServiceOperationInfo = typedoperationinfo3;
            // 
            // setStateActivity2
            // 
            this.setStateActivity2.Name = "setStateActivity2";
            this.setStateActivity2.TargetStateName = "Done";
            // 
            // receiveActivity3
            // 
            this.receiveActivity3.CanCreateInstance = true;
            this.receiveActivity3.Name = "receiveActivity3";
            typedoperationinfo4.ContractType = typeof(BlogCheckListContracts.IBlogAPI);
            typedoperationinfo4.Name = "AddEntry";
            this.receiveActivity3.ServiceOperationInfo = typedoperationinfo4;
            // 
            // setStateActivity1
            // 
            this.setStateActivity1.Name = "setStateActivity1";
            this.setStateActivity1.TargetStateName = "Done";
            // 
            // receiveActivity2
            // 
            this.receiveActivity2.Activities.Add(this.generateBlogActivity1);
            this.receiveActivity2.CanCreateInstance = true;
            this.receiveActivity2.Name = "receiveActivity2";
            activitybind1.Name = "generateBlogActivity1";
            activitybind1.Path = "Atom10Feed";
            workflowparameterbinding1.ParameterName = "(ReturnValue)";
            workflowparameterbinding1.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            this.receiveActivity2.ParameterBindings.Add(workflowparameterbinding1);
            typedoperationinfo5.ContractType = typeof(BlogCheckListContracts.IBlogAPI);
            typedoperationinfo5.Name = "GetBlog";
            this.receiveActivity2.ServiceOperationInfo = typedoperationinfo5;
            // 
            // UpdateEntryEvent
            // 
            this.UpdateEntryEvent.Activities.Add(this.receiveActivity1);
            this.UpdateEntryEvent.Activities.Add(this.setStateActivity5);
            this.UpdateEntryEvent.Name = "UpdateEntryEvent";
            // 
            // DeleteEntryEvent
            // 
            this.DeleteEntryEvent.Activities.Add(this.receiveActivity4);
            this.DeleteEntryEvent.Activities.Add(this.setStateActivity4);
            this.DeleteEntryEvent.Name = "DeleteEntryEvent";
            // 
            // GetEntryEvent
            // 
            this.GetEntryEvent.Activities.Add(this.receiveActivity5);
            this.GetEntryEvent.Activities.Add(this.setStateActivity3);
            this.GetEntryEvent.Name = "GetEntryEvent";
            // 
            // AddEntryEvent
            // 
            this.AddEntryEvent.Activities.Add(this.receiveActivity3);
            this.AddEntryEvent.Activities.Add(this.setStateActivity2);
            this.AddEntryEvent.Name = "AddEntryEvent";
            // 
            // GetBlogEvent
            // 
            this.GetBlogEvent.Activities.Add(this.receiveActivity2);
            this.GetBlogEvent.Activities.Add(this.setStateActivity1);
            this.GetBlogEvent.Name = "GetBlogEvent";
            // 
            // Done
            // 
            this.Done.Name = "Done";
            // 
            // StateMachineBlogAPIServiceInitialState
            // 
            this.StateMachineBlogAPIServiceInitialState.Activities.Add(this.GetBlogEvent);
            this.StateMachineBlogAPIServiceInitialState.Activities.Add(this.AddEntryEvent);
            this.StateMachineBlogAPIServiceInitialState.Activities.Add(this.GetEntryEvent);
            this.StateMachineBlogAPIServiceInitialState.Activities.Add(this.DeleteEntryEvent);
            this.StateMachineBlogAPIServiceInitialState.Activities.Add(this.UpdateEntryEvent);
            this.StateMachineBlogAPIServiceInitialState.Name = "StateMachineBlogAPIServiceInitialState";
            workflowserviceattributes1.ConfigurationName = "BlogChecklistLibrary.StateMachineBlogAPIService";
            workflowserviceattributes1.Name = "StateMachineBlogAPIService";
            // 
            // StateMachineBlogAPIService
            // 
            this.Activities.Add(this.StateMachineBlogAPIServiceInitialState);
            this.Activities.Add(this.Done);
            this.CompletedStateName = "Done";
            this.DynamicUpdateCondition = null;
            this.InitialStateName = "StateMachineBlogAPIServiceInitialState";
            this.Name = "StateMachineBlogAPIService";
            this.SetValue(System.Workflow.Activities.ReceiveActivity.WorkflowServiceAttributesProperty, workflowserviceattributes1);
            this.CanModifyActivities = false;

        }

        #endregion

        private EventDrivenActivity AddEntryEvent;
        private EventDrivenActivity GetBlogEvent;
        private SetStateActivity setStateActivity5;
        private SetStateActivity setStateActivity4;
        private SetStateActivity setStateActivity3;
        private SetStateActivity setStateActivity2;
        private SetStateActivity setStateActivity1;
        private EventDrivenActivity UpdateEntryEvent;
        private EventDrivenActivity DeleteEntryEvent;
        private EventDrivenActivity GetEntryEvent;
        private StateActivity Done;
        private ReceiveActivity receiveActivity1;
        private ReceiveActivity receiveActivity4;
        private ReceiveActivity receiveActivity5;
        private ReceiveActivity receiveActivity3;
        private ReceiveActivity receiveActivity2;
        private GenerateBlogActivity generateBlogActivity1;
        private StateActivity StateMachineBlogAPIServiceInitialState;














    }
}
