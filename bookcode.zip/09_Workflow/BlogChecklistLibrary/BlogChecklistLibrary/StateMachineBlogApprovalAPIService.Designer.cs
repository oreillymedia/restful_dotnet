﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace BlogChecklistLibrary
{
    partial class StateMachineBlogApprovalAPIService
    {
        #region Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
            this.CanModifyActivities = true;
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding1 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo1 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding2 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding3 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo2 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.ComponentModel.ActivityBind activitybind6 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding4 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo3 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.ComponentModel.ActivityBind activitybind7 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding5 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind8 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding6 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo4 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.ComponentModel.ActivityBind activitybind9 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding7 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo5 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.ComponentModel.ActivityBind activitybind10 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding8 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.ComponentModel.ActivityBind activitybind11 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding9 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
            System.Workflow.Activities.TypedOperationInfo typedoperationinfo6 = new System.Workflow.Activities.TypedOperationInfo();
            System.Workflow.Activities.WorkflowServiceAttributes workflowserviceattributes1 = new System.Workflow.Activities.WorkflowServiceAttributes();
            this.approveEntryActivity1 = new BlogChecklistLibrary.ApproveEntryActivity();
            this.generateBlogActivity1 = new BlogChecklistLibrary.GenerateBlogActivity();
            this.addEntryActivity1 = new BlogChecklistLibrary.AddEntryActivity();
            this.setStateActivity6 = new System.Workflow.Activities.SetStateActivity();
            this.receiveActivity6 = new System.Workflow.Activities.ReceiveActivity();
            this.setStateActivity5 = new System.Workflow.Activities.SetStateActivity();
            this.receiveActivity5 = new System.Workflow.Activities.ReceiveActivity();
            this.setStateActivity4 = new System.Workflow.Activities.SetStateActivity();
            this.receiveActivity4 = new System.Workflow.Activities.ReceiveActivity();
            this.setStateActivity3 = new System.Workflow.Activities.SetStateActivity();
            this.receiveActivity3 = new System.Workflow.Activities.ReceiveActivity();
            this.setStateActivity1 = new System.Workflow.Activities.SetStateActivity();
            this.receiveActivity2 = new System.Workflow.Activities.ReceiveActivity();
            this.setStateActivity2 = new System.Workflow.Activities.SetStateActivity();
            this.receiveActivity1 = new System.Workflow.Activities.ReceiveActivity();
            this.GetEntry = new System.Workflow.Activities.EventDrivenActivity();
            this.UpdateEntry = new System.Workflow.Activities.EventDrivenActivity();
            this.DeleteEntry = new System.Workflow.Activities.EventDrivenActivity();
            this.ApproveEntry = new System.Workflow.Activities.EventDrivenActivity();
            this.GetBlog = new System.Workflow.Activities.EventDrivenActivity();
            this.AddEntry = new System.Workflow.Activities.EventDrivenActivity();
            this.Editing = new System.Workflow.Activities.StateActivity();
            this.Done = new System.Workflow.Activities.StateActivity();
            this.StateMachineBlogApprovalAPIServiceInitialState = new System.Workflow.Activities.StateActivity();
            // 
            // approveEntryActivity1
            // 
            activitybind1.Name = "StateMachineBlogApprovalAPIService";
            activitybind1.Path = "Entry";
            this.approveEntryActivity1.Name = "approveEntryActivity1";
            this.approveEntryActivity1.SetBinding(BlogChecklistLibrary.ApproveEntryActivity.EntryProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            // 
            // generateBlogActivity1
            // 
            this.generateBlogActivity1.Atom10Feed = null;
            this.generateBlogActivity1.Name = "generateBlogActivity1";
            // 
            // addEntryActivity1
            // 
            activitybind2.Name = "StateMachineBlogApprovalAPIService";
            activitybind2.Path = "Entry";
            this.addEntryActivity1.Name = "addEntryActivity1";
            this.addEntryActivity1.SetBinding(BlogChecklistLibrary.AddEntryActivity.EntryProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
            // 
            // setStateActivity6
            // 
            this.setStateActivity6.Name = "setStateActivity6";
            this.setStateActivity6.TargetStateName = "Editing";
            // 
            // receiveActivity6
            // 
            this.receiveActivity6.Name = "receiveActivity6";
            activitybind3.Name = "StateMachineBlogApprovalAPIService";
            activitybind3.Path = "Entry";
            workflowparameterbinding1.ParameterName = "(ReturnValue)";
            workflowparameterbinding1.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
            this.receiveActivity6.ParameterBindings.Add(workflowparameterbinding1);
            typedoperationinfo1.ContractType = typeof(BlogCheckListContracts.IBlogApprovalAPI);
            typedoperationinfo1.Name = "GetEntry";
            this.receiveActivity6.ServiceOperationInfo = typedoperationinfo1;
            // 
            // setStateActivity5
            // 
            this.setStateActivity5.Name = "setStateActivity5";
            this.setStateActivity5.TargetStateName = "Editing";
            // 
            // receiveActivity5
            // 
            this.receiveActivity5.Name = "receiveActivity5";
            activitybind4.Name = "StateMachineBlogApprovalAPIService";
            activitybind4.Path = "Entry";
            workflowparameterbinding2.ParameterName = "entry";
            workflowparameterbinding2.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
            activitybind5.Name = "StateMachineBlogApprovalAPIService";
            activitybind5.Path = "Entry";
            workflowparameterbinding3.ParameterName = "(ReturnValue)";
            workflowparameterbinding3.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
            this.receiveActivity5.ParameterBindings.Add(workflowparameterbinding2);
            this.receiveActivity5.ParameterBindings.Add(workflowparameterbinding3);
            typedoperationinfo2.ContractType = typeof(BlogCheckListContracts.IBlogApprovalAPI);
            typedoperationinfo2.Name = "UpateEntry";
            this.receiveActivity5.ServiceOperationInfo = typedoperationinfo2;
            // 
            // setStateActivity4
            // 
            this.setStateActivity4.Name = "setStateActivity4";
            this.setStateActivity4.TargetStateName = "Done";
            // 
            // receiveActivity4
            // 
            this.receiveActivity4.Name = "receiveActivity4";
            activitybind6.Name = "StateMachineBlogApprovalAPIService";
            activitybind6.Path = "Entry";
            workflowparameterbinding4.ParameterName = "(ReturnValue)";
            workflowparameterbinding4.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind6)));
            this.receiveActivity4.ParameterBindings.Add(workflowparameterbinding4);
            typedoperationinfo3.ContractType = typeof(BlogCheckListContracts.IBlogApprovalAPI);
            typedoperationinfo3.Name = "DeleteEntry";
            this.receiveActivity4.ServiceOperationInfo = typedoperationinfo3;
            // 
            // setStateActivity3
            // 
            this.setStateActivity3.Name = "setStateActivity3";
            this.setStateActivity3.TargetStateName = "Done";
            // 
            // receiveActivity3
            // 
            this.receiveActivity3.Activities.Add(this.approveEntryActivity1);
            this.receiveActivity3.Name = "receiveActivity3";
            activitybind7.Name = "StateMachineBlogApprovalAPIService";
            activitybind7.Path = "Entry";
            workflowparameterbinding5.ParameterName = "entry";
            workflowparameterbinding5.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind7)));
            activitybind8.Name = "StateMachineBlogApprovalAPIService";
            activitybind8.Path = "Entry";
            workflowparameterbinding6.ParameterName = "(ReturnValue)";
            workflowparameterbinding6.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind8)));
            this.receiveActivity3.ParameterBindings.Add(workflowparameterbinding5);
            this.receiveActivity3.ParameterBindings.Add(workflowparameterbinding6);
            typedoperationinfo4.ContractType = typeof(BlogCheckListContracts.IBlogApprovalAPI);
            typedoperationinfo4.Name = "ApproveEntry";
            this.receiveActivity3.ServiceOperationInfo = typedoperationinfo4;
            // 
            // setStateActivity1
            // 
            this.setStateActivity1.Name = "setStateActivity1";
            this.setStateActivity1.TargetStateName = "Done";
            // 
            // receiveActivity2
            // 
            this.receiveActivity2.Activities.Add(this.generateBlogActivity1);
            this.receiveActivity2.CanCreateInstance = true;
            this.receiveActivity2.Name = "receiveActivity2";
            activitybind9.Name = "generateBlogActivity1";
            activitybind9.Path = "Atom10Feed";
            workflowparameterbinding7.ParameterName = "(ReturnValue)";
            workflowparameterbinding7.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind9)));
            this.receiveActivity2.ParameterBindings.Add(workflowparameterbinding7);
            typedoperationinfo5.ContractType = typeof(BlogCheckListContracts.IBlogApprovalAPI);
            typedoperationinfo5.Name = "GetBlog";
            this.receiveActivity2.ServiceOperationInfo = typedoperationinfo5;
            // 
            // setStateActivity2
            // 
            this.setStateActivity2.Name = "setStateActivity2";
            this.setStateActivity2.TargetStateName = "Editing";
            // 
            // receiveActivity1
            // 
            this.receiveActivity1.Activities.Add(this.addEntryActivity1);
            this.receiveActivity1.CanCreateInstance = true;
            this.receiveActivity1.Name = "receiveActivity1";
            activitybind10.Name = "StateMachineBlogApprovalAPIService";
            activitybind10.Path = "Entry";
            workflowparameterbinding8.ParameterName = "entry";
            workflowparameterbinding8.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind10)));
            activitybind11.Name = "addEntryActivity1";
            activitybind11.Path = "Entry";
            workflowparameterbinding9.ParameterName = "(ReturnValue)";
            workflowparameterbinding9.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind11)));
            this.receiveActivity1.ParameterBindings.Add(workflowparameterbinding8);
            this.receiveActivity1.ParameterBindings.Add(workflowparameterbinding9);
            typedoperationinfo6.ContractType = typeof(BlogCheckListContracts.IBlogApprovalAPI);
            typedoperationinfo6.Name = "AddEntry";
            this.receiveActivity1.ServiceOperationInfo = typedoperationinfo6;
            // 
            // GetEntry
            // 
            this.GetEntry.Activities.Add(this.receiveActivity6);
            this.GetEntry.Activities.Add(this.setStateActivity6);
            this.GetEntry.Name = "GetEntry";
            // 
            // UpdateEntry
            // 
            this.UpdateEntry.Activities.Add(this.receiveActivity5);
            this.UpdateEntry.Activities.Add(this.setStateActivity5);
            this.UpdateEntry.Name = "UpdateEntry";
            // 
            // DeleteEntry
            // 
            this.DeleteEntry.Activities.Add(this.receiveActivity4);
            this.DeleteEntry.Activities.Add(this.setStateActivity4);
            this.DeleteEntry.Name = "DeleteEntry";
            // 
            // ApproveEntry
            // 
            this.ApproveEntry.Activities.Add(this.receiveActivity3);
            this.ApproveEntry.Activities.Add(this.setStateActivity3);
            this.ApproveEntry.Name = "ApproveEntry";
            // 
            // GetBlog
            // 
            this.GetBlog.Activities.Add(this.receiveActivity2);
            this.GetBlog.Activities.Add(this.setStateActivity1);
            this.GetBlog.Name = "GetBlog";
            // 
            // AddEntry
            // 
            this.AddEntry.Activities.Add(this.receiveActivity1);
            this.AddEntry.Activities.Add(this.setStateActivity2);
            this.AddEntry.Name = "AddEntry";
            // 
            // Editing
            // 
            this.Editing.Activities.Add(this.ApproveEntry);
            this.Editing.Activities.Add(this.DeleteEntry);
            this.Editing.Activities.Add(this.UpdateEntry);
            this.Editing.Activities.Add(this.GetEntry);
            this.Editing.Name = "Editing";
            // 
            // Done
            // 
            this.Done.Name = "Done";
            // 
            // StateMachineBlogApprovalAPIServiceInitialState
            // 
            this.StateMachineBlogApprovalAPIServiceInitialState.Activities.Add(this.AddEntry);
            this.StateMachineBlogApprovalAPIServiceInitialState.Activities.Add(this.GetBlog);
            this.StateMachineBlogApprovalAPIServiceInitialState.Name = "StateMachineBlogApprovalAPIServiceInitialState";
            workflowserviceattributes1.ConfigurationName = "BlogChecklistLibrary.StateMachineBlogApprovalAPIService";
            workflowserviceattributes1.Name = "StateMachineBlogApprovalAPIService";
            // 
            // StateMachineBlogApprovalAPIService
            // 
            this.Activities.Add(this.StateMachineBlogApprovalAPIServiceInitialState);
            this.Activities.Add(this.Done);
            this.Activities.Add(this.Editing);
            this.CompletedStateName = "Done";
            this.DynamicUpdateCondition = null;
            this.InitialStateName = "StateMachineBlogApprovalAPIServiceInitialState";
            this.Name = "StateMachineBlogApprovalAPIService";
            this.SetValue(System.Workflow.Activities.ReceiveActivity.WorkflowServiceAttributesProperty, workflowserviceattributes1);
            this.CanModifyActivities = false;

        }

        #endregion

        private SetStateActivity setStateActivity5;
        private SetStateActivity setStateActivity4;
        private SetStateActivity setStateActivity3;
        private SetStateActivity setStateActivity1;
        private SetStateActivity setStateActivity2;
        private EventDrivenActivity UpdateEntry;
        private EventDrivenActivity DeleteEntry;
        private EventDrivenActivity ApproveEntry;
        private EventDrivenActivity GetBlog;
        private EventDrivenActivity AddEntry;
        private StateActivity Editing;
        private StateActivity Done;
        private GenerateBlogActivity generateBlogActivity1;
        private ReceiveActivity receiveActivity5;
        private ReceiveActivity receiveActivity4;
        private ReceiveActivity receiveActivity3;
        private ReceiveActivity receiveActivity2;
        private ReceiveActivity receiveActivity1;
        private SetStateActivity setStateActivity6;
        private ReceiveActivity receiveActivity6;
        private EventDrivenActivity GetEntry;
        private AddEntryActivity addEntryActivity1;
        private ApproveEntryActivity approveEntryActivity1;
        private StateActivity StateMachineBlogApprovalAPIServiceInitialState;




























    }
}
