﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel;
using System.ServiceModel.Syndication;

namespace BlogChecklistLibrary
{
	public class CreateAtomItemActivity : Activity
	{
        public static DependencyProperty AtomEntryProperty = DependencyProperty.Register("AtomEntry", typeof(Atom10ItemFormatter), typeof(CreateAtomItemActivity));

        [System.ComponentModel.DescriptionAttribute("AtomEntry")]
        [System.ComponentModel.CategoryAttribute("AtomEntry Category")]
        [System.ComponentModel.BrowsableAttribute(true)]
        [System.ComponentModel.DesignerSerializationVisibilityAttribute(System.ComponentModel.DesignerSerializationVisibility.Visible)]
        public Atom10ItemFormatter AtomEntry
        {
            get
            {
                return ((Atom10ItemFormatter)(base.GetValue(CreateAtomItemActivity.AtomEntryProperty)));
            }
            set
            {
                base.SetValue(CreateAtomItemActivity.AtomEntryProperty, value);
            }
        }
        public static DependencyProperty SyndicationItemProperty = DependencyProperty.Register("SyndicationItem", typeof(SyndicationItem ), typeof(CreateAtomItemActivity));

        [System.ComponentModel.DescriptionAttribute("SyndicationItem")]
        [System.ComponentModel.CategoryAttribute("SyndicationItem Category")]
        [System.ComponentModel.BrowsableAttribute(true)]
        [System.ComponentModel.DesignerSerializationVisibilityAttribute(System.ComponentModel.DesignerSerializationVisibility.Visible)]
        public SyndicationItem  SyndicationItem
        {
            get
            {
                return ((SyndicationItem )(base.GetValue(CreateAtomItemActivity.SyndicationItemProperty)));
            }
            set
            {
                base.SetValue(CreateAtomItemActivity.SyndicationItemProperty, value);
            }
        }
        protected override ActivityExecutionStatus Execute(ActivityExecutionContext executionContext)
        {
            this.AtomEntry = new Atom10ItemFormatter(this.SyndicationItem);
            return ActivityExecutionStatus.Closed;
        }
	}
}
