﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using System.ServiceModel.Syndication;

namespace EventLogFeed
{
    [ServiceContract]
    public class Feed 
    {
        [OperationContract]
        [WebGet(UriTemplate = "atom")]
        public Atom10FeedFormatter GetAtom()
        {
            return null;
        }
        

    }
}
