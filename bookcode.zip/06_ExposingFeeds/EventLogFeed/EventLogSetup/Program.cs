﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace EventLogSetup
{
    class Program
    {
        static void Main(string[] args)
        {
            EventLog el = new EventLog("Application");
            el.Clear();
            EventLog.WriteEntry("EventLogTest", "Testing Event Log API", EventLogEntryType.Error,1,2);
            EventLog.WriteEntry("EventLogTest", "Testing Event Log API - again", EventLogEntryType.Error,2,2);

            EventLog.WriteEntry("EventLogTest", "Testing Event Log API - yet again", EventLogEntryType.Error, 3, 2);
   
        }
    }
}
