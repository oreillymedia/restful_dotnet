﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Web;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.IO;
using System.ServiceModel.Channels;
using System.Xml;
using System.Xml.Serialization;
using System.Net;
using Flanders.WCF.SSDS;
using schemas.microsoft.com.sitka._2008._03;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Authority authority = new Authority();
            authority.Id = "booktestnew";
            foreach (var item in authority.Containers)
            {
                Console.WriteLine(item.Id);
            }
            Container c = new Container { Id ="booktest2"};
            authority.Containers.Add(c);
            //string auth = "dctest";
            //CreateAuthority(auth);
            //GetAuthority(auth);
            //CreateContainer(auth, "dctestcontainer");
            //GetContainer(auth, "dctestcontainer");
            //GetAuthority("xmlserializertest");
//            string authority = "booktestnew";
//            GetContainers(authority, string.Empty);
//           // CreateAuthority(authority);
//            string container = "booktestcontainer";
//            //GetContainer(authority, container);
//            //CreateContainer(authority, container);
//            string entity = "booktestentity" + Guid.NewGuid().ToString();
//            CreateEntity(authority, container, entity);
//            GetEntity(authority, container, entity);
//            //DeleteEntity(authority, container, entity);
//GetContainersEntities(authority, container,String.Empty);
//string q  = "from e in entities where e[\"TestElement\"]==\"Queryable\" select e";
//GetContainersEntities(authority, container, q);
           

        }
        private static void GetContainers(string authority, string query)
        {
            WebChannelFactory<IContainer> cf = GetChannelFactory(authority);
            IContainer channel = cf.CreateChannel();

            using (new OperationContextScope((IContextChannel)channel))
            {
                ContainerEntitySet es = channel.GetContainers(query);
                Console.WriteLine("Authority has the following containers");
                foreach (var item in es)
                {
                    Console.WriteLine(item.Id );
                   
                } 
            }
        }

private static void GetContainer(string authority, string container)
{
    WebChannelFactory<IContainer> cf = GetChannelFactory(authority);
    IContainer channel = cf.CreateChannel();

    using (new OperationContextScope((IContextChannel)channel))
    {
        Container c = channel.GetContainer(container);
    }
}
private static void DeleteContainer(string authority, string container)
{
    WebChannelFactory<IContainer> cf = GetChannelFactory(authority);
    IContainer channel = cf.CreateChannel();

    using (new OperationContextScope((IContextChannel)channel))
    {
        channel.DeleteContainer(container);
    }
}
        
private static void GetContainersEntities(string authority, string container,string query)
{
    WebChannelFactory<IContainer> cf = GetChannelFactory(authority);
    IContainer channel = cf.CreateChannel();

    using (new OperationContextScope((IContextChannel)channel))
    {
        string theQuery = String.IsNullOrEmpty(query) ? "''" : String.Format("'{0}'", query);
        EntitySet  es = channel.GetContainersEntities(container, theQuery);
        Console.WriteLine("Container has {0} entities",es.Count.ToString());
        foreach (var item in es)
        {
            Console.WriteLine("Entity {0}",item.Name);
        }
    }
}

private static void GetEntity(string authority, string container, string entity)
{
    WebChannelFactory<IContainer> cf = GetChannelFactory(authority);
    IContainer channel = cf.CreateChannel();

    using (new OperationContextScope((IContextChannel)channel))
    {
        SSDSEntityFormatter ef  = channel.GetEntity(container, entity);
    }
}

private static void GetAuthority(string authority)
{
    WebChannelFactory<IContainer> cf = GetChannelFactory(authority);
    IContainer channel = cf.CreateChannel();
    using (new OperationContextScope((IContextChannel)channel))
    {
        OutgoingWebRequestContext ctx = WebOperationContext.Current.OutgoingRequest;
        ctx.Accept = ContentType;
        Authority auth = channel.GetAuthority();
        IncomingWebResponseContext rctx = WebOperationContext.Current.IncomingResponse;
        if (rctx.StatusCode == System.Net.HttpStatusCode.OK)
            Console.WriteLine("Authority {0} {1} retrieved!", auth.Id, auth.Version);
    }
}
private static void UpdateEntity(string authority, string container, string entity,SSDSEntityFormatter theEntity)
{
    WebChannelFactory<IContainer> cf = GetChannelFactory(authority);
    IContainer channel = cf.CreateChannel();

    using (new OperationContextScope((IContextChannel)channel))
    {
        OutgoingWebRequestContext ctx = WebOperationContext.Current.OutgoingRequest;
        ctx.ContentType = ContentType;
        channel.UpdateEntity(container, entity, theEntity);
        IncomingWebResponseContext rctx = WebOperationContext.Current.IncomingResponse;
        if (rctx.StatusCode == System.Net.HttpStatusCode.OK)
            Console.WriteLine("Entity {0} deleted!", entity);

    }
}
private static void DeleteEntity(string authority, string container, string entity)
{
    WebChannelFactory<IContainer> cf = GetChannelFactory(authority);
    IContainer channel = cf.CreateChannel();

    using (new OperationContextScope((IContextChannel)channel))
    {
        OutgoingWebRequestContext ctx = WebOperationContext.Current.OutgoingRequest;
        ctx.ContentType = ContentType;
        channel.DeleteEntity(container, entity);
        IncomingWebResponseContext rctx = WebOperationContext.Current.IncomingResponse;
        if (rctx.StatusCode == System.Net.HttpStatusCode.OK)
            Console.WriteLine("Entity {0} deleted!", entity);

    }
}

private static void CreateEntity(string authority, string container, string entity)
{
    WebChannelFactory<IContainer> cf = GetChannelFactory(authority);
    Container c = new Container { Id = container };
    IContainer channel = cf.CreateChannel();
    SSDSEntityFormatter flexEntity = new DerivedSSDSEntityFormatter();
    flexEntity.Name = "Test";
    flexEntity.Id = entity;
    StringProperty property = new StringProperty
    {
        StringValue = "Testing",
        Name = "TestElement"
    };
    List<SSDSEntityFlexibleProperty> props = new List<SSDSEntityFlexibleProperty>();
    props.Add(property);
    flexEntity.FlexibleProperties = props;
    using (new OperationContextScope((IContextChannel)channel))
    {
        //OutgoingWebRequestContext ctx = WebOperationContext.Current.OutgoingRequest;
        //ctx.ContentType = ContentType;
        channel.CreateEntity(container, flexEntity);
        IncomingWebResponseContext rctx = WebOperationContext.Current.IncomingResponse;
        if (rctx.StatusCode == System.Net.HttpStatusCode.Created)
            Console.WriteLine("Entity {0} created!", entity);

    }
}

private static void CreateContainer(string authority, string container)
{
    WebChannelFactory<IContainer> cf = GetChannelFactory(authority);
    Container c = new Container { Id = container };
    IContainer channel = cf.CreateChannel();
    using (new OperationContextScope((IContextChannel)channel))
    {
        OutgoingWebRequestContext ctx = WebOperationContext.Current.OutgoingRequest;
        ctx.ContentType = ContentType;
        channel.CreateContainer(c);
        IncomingWebResponseContext rctx = WebOperationContext.Current.IncomingResponse;
        if (rctx.StatusCode == System.Net.HttpStatusCode.Created)
            Console.WriteLine("Container {0} created!", container);

    }
}
static WebChannelFactory<IContainer> GetChannelFactory(string authority)
{
    //create the WebHttpBinding, and set its properties
    WebHttpBinding binding = new WebHttpBinding();          
    binding.Security.Mode = WebHttpSecurityMode.TransportCredentialOnly;
    binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
    //SDSS sends back chunked responses
    binding.TransferMode = TransferMode.StreamedResponse;
    //Copy the WebHttpBinding into a CustomBinding
    CustomBinding custom = new CustomBinding(binding);
    //Get the encoding element
    WebMessageEncodingBindingElement be = 
        custom.Elements.Find<WebMessageEncodingBindingElement>();
    //set the content type mapper
    be.ContentTypeMapper = new SDSSContentTypeMapper();
    //create the URI
    string uri = String.Format(AuthorityUri, authority);
//create the WebChannelFactory
WebChannelFactory<IContainer> cf =
    new WebChannelFactory<IContainer>(custom,
                                            new Uri(uri));
cf.Endpoint.Behaviors.Add(new ContentTypeBehavior { ContentType = ContentType });
//set the credentials
    cf.Credentials.UserName.UserName = Username;
    cf.Credentials.UserName.Password = Password;           
    return cf;
    }
static void CreateAuthority(string authorityId)
{
    WebHttpBinding binding = new WebHttpBinding();
    binding.Security.Mode = WebHttpSecurityMode.TransportCredentialOnly;
    binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
    WebChannelFactory<ICreateAuthority> cf =
        new WebChannelFactory<ICreateAuthority>(binding,
                                                new Uri(ServiceUri));
    cf.Credentials.UserName.UserName = Username;
    cf.Credentials.UserName.Password = Password;
    Authority authority = new Authority { Id = authorityId };
    ICreateAuthority channel = cf.CreateChannel();
    using (new OperationContextScope((IContextChannel)channel))
    {
        OutgoingWebRequestContext ctx = WebOperationContext.Current.OutgoingRequest;
        ctx.ContentType = ContentType;
        channel.CreateAuthority(authority);
        IncomingWebResponseContext rctx = WebOperationContext.Current.IncomingResponse;
        if (rctx.StatusCode == System.Net.HttpStatusCode.Created)
            Console.WriteLine("Authority {0} created!", authorityId);
    }
}
static string ContentType = "application/x-ssds+xml";
static string Username = "jonflanders1";
static string Password = "LT1#YF#WMxgsSBeDCNiD";
static string ServiceUri = "http://data.beta.mssds.com/v1/";
static string AuthorityUri = "http://{0}.data.beta.mssds.com/v1/";
    }

}
