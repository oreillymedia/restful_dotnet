﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Channels;
using schemas.microsoft.com.sitka._2008._03;
using Flanders.WCF.SSDS;

namespace schemas.microsoft.com.sitka._2008._03
{
    public partial class Authority
    {

        public ContainerEntitySet Containers
        {
            get {
                if (_containers == null)
                    _containers = this.GetContainers();

                return _containers;
            }
        }
        ContainerEntitySet _containers;
    }
}
