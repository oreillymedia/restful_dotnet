﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Xml;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Xml.Schema;
using System.IO;
using schemas.microsoft.com.sitka._2008._03;

namespace Flanders.WCF.SSDS
{
    [XmlRoot("FeedEntry")]
    public class DerivedSSDSEntityFormatter : SSDSEntityFormatter
    {
    }

    public class SSDSEntityFormatter : IXmlSerializable
    {
        public Container Container { get; set; }
        public string Id { get; set; }
        public string Version { get; set; }
        public string Kind { get; set; }
        public string Name { get; set; }

        string _SSDSNS = "http://schemas.microsoft.com/sitka/2008/03/";
        public IList<SSDSEntityFlexibleProperty> FlexibleProperties { get; set; }
        #region IXmlSerializable Members

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(XmlReader reader)
        {
            List<SSDSEntityFlexibleProperty> props = new List<SSDSEntityFlexibleProperty>();
            this.FlexibleProperties = props;
            string name = reader.LocalName;
            this.Name = name;
            //move past top element
            reader.Read();
            while (reader.Read() && reader.LocalName != name)
            {
                if (reader.LocalName == "Id" && reader.NodeType == XmlNodeType.Element)
                {
                    this.Id = reader.ReadElementContentAsString();
                }
                if (reader.LocalName == "Version" && reader.NodeType == XmlNodeType.Element)
                {
                    this.Version = reader.ReadElementContentAsString();
                }
                if (reader.NodeType == XmlNodeType.Element && reader.NamespaceURI != _SSDSNS)
                {
                    switch (reader[0])
                    {
                        case "x:string":
                            props.Add(new StringProperty { StringValue = reader.ReadElementContentAsString(), Name = reader.LocalName });
                            break;
                        case "x:base64Binary":
                            int readBytes = 0;
                            byte[] buffer = new byte[1000];
                            MemoryStream ms = new MemoryStream();
                            BinaryWriter bw = new BinaryWriter(ms);
                            while ((readBytes = reader.ReadElementContentAsBase64(buffer, 0, 50)) > 0)
                            {
                                bw.Write(buffer, 0, readBytes);
                            }

                            props.Add(new Base64Property { Base64Value = ms.GetBuffer(), Name = reader.LocalName });
                            break;
                        case "dateTime":
                            props.Add(new DateTimeProperty { DateTimeValue = reader.ReadContentAsDateTime(), Name = reader.LocalName });
                            break;
                        case "decimal":
                            props.Add(new DecimalProperty { DecimalValue = reader.ReadContentAsDecimal(), Name = reader.LocalName });

                            break;
                        case "boolean":
                            props.Add(new BooleanProperty { BooleanValue = reader.ReadContentAsBoolean(), Name = reader.LocalName });

                            break;
                        default:
                            break;
                    }
                }
            }
            //read end element
            reader.Read();
        }

        public void WriteXml(XmlWriter writer)
        {
            writer.WriteAttributeString("xmlns", "xsi", null, "http://www.w3.org/2001/XMLSchema-instance");
            writer.WriteAttributeString("xmlns", "xsd", null, "http://www.w3.org/2001/XMLSchema");
            writer.WriteElementString("Id", _SSDSNS, this.Id);
            if (this.Version != null)
                writer.WriteElementString("Version", _SSDSNS, this.Version);
            if (this.FlexibleProperties != null)
            {
                foreach (var item in this.FlexibleProperties)
                {
                    item.WriteXml(writer);
                }
            }
          
        }

        #endregion
    }
    public abstract class SSDSEntityFlexibleProperty
    {
        public string Name { get; set; }
        protected string XSDType { get; set; }
        protected internal virtual void WriteXml(XmlWriter writer)
        {
            writer.WriteStartElement(this.Name);
            writer.WriteAttributeString(_attr,
                                        _ns,
                                        String.Format("xsd:{0}", this.XSDType));
            writer.WriteString(this.GetValue());
            writer.WriteEndElement();
        }
        protected internal abstract string GetValue();
        private string _ns = "http://www.w3.org/2001/XMLSchema-instance";
        private string _attr = "type";
    }
    public class StringProperty : SSDSEntityFlexibleProperty
    {
        public string StringValue { get; set; }

        public StringProperty()
        {
            this.XSDType = "string";
        }

        protected internal override string GetValue()
        {
            return this.StringValue;
        }
    }
    public class Base64Property : SSDSEntityFlexibleProperty
    {
        public Base64Property()
        {
            this.XSDType = "base64Binary";
        }
        public byte[] Base64Value { get; set; }
        protected internal override string GetValue()
        {
            return Convert.ToBase64String(this.Base64Value);
        }

    }
    public class BooleanProperty : SSDSEntityFlexibleProperty
    {
        public BooleanProperty()
        {
            this.XSDType = "boolean";
        }
        protected internal override string GetValue()
        {
            return this.BooleanValue.ToString();
        }
        public bool BooleanValue { get; set; }
    }
    public class DecimalProperty : SSDSEntityFlexibleProperty
    {
        public DecimalProperty()
        {
            this.XSDType = "decimal";
        }
        protected internal override string GetValue()
        {
            return this.DecimalValue.ToString();
        }
        public decimal DecimalValue { get; set; }
    }
    public class DateTimeProperty : SSDSEntityFlexibleProperty
    {
        public DateTimeProperty()
        {
            this.XSDType = "dateTime";
        }
        protected internal override string GetValue()
        {
            return this.DateTimeValue.ToString();
        }
        public DateTime DateTimeValue { get; set; }


    }
    
}

