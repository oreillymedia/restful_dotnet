﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using schemas.microsoft.com.sitka._2008._03;

namespace Flanders.WCF.SSDS
{
    [CollectionDataContract(Name = "EntitySet", Namespace = "http://schemas.microsoft.com/sitka/2008/03/")]
    public class ContainerEntitySet : List<Container>
    {
        public Authority Authority { get; set; }
        public new void Add(Container c)
        {
            c.Authority = this.Authority;
            c.CreateContainer();
            ((ICollection<Container>)this).Add(c);
        }
    }
}
