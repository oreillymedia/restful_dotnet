﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Web;
using schemas.microsoft.com.sitka._2008._03;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Flanders.WCF.SSDS
{
    public static class SSDSExtensionMethods
    {
        internal static ContainerEntitySet GetContainers(this Authority a)
        {
            ContainerEntitySet es =  GetContainers(a, String.Empty);
            es.Authority = a;
            return es;
        }
        private static ContainerEntitySet GetContainers(Authority a, string query)
        {
            WebChannelFactory<IContainer> cf = GetChannelFactory(a);
            IContainer channel = cf.CreateChannel();
            ContainerEntitySet es = null;
            using (new OperationContextScope((IContextChannel)channel))
            {
                es = channel.GetContainers(query);
            }
            if (es == null)
                es = new ContainerEntitySet();
            foreach (var item in es)
            {
                item.Authority = a;
            }
            return es;
        }

        private static void GetContainer(Authority a, string container)
        {
            WebChannelFactory<IContainer> cf = GetChannelFactory(a);
            IContainer channel = cf.CreateChannel();

            using (new OperationContextScope((IContextChannel)channel))
            {
                Container c = channel.GetContainer(container);
            }
        }
        private static void DeleteContainer(Authority a, string container)
        {
            WebChannelFactory<IContainer> cf = GetChannelFactory(a);
            IContainer channel = cf.CreateChannel();

            using (new OperationContextScope((IContextChannel)channel))
            {
                channel.DeleteContainer(container);
            }
        }
        internal static EntitySet GetEntities(this Container c)
        {
            return GetContainersEntities(c.Authority,c,String.Empty);
        }
        private static EntitySet GetContainersEntities(Authority a, Container container, string query)
        {
            WebChannelFactory<IContainer> cf = GetChannelFactory(a);
            IContainer channel = cf.CreateChannel();
            EntitySet es = null;
            using (new OperationContextScope((IContextChannel)channel))
            {
                string theQuery = String.IsNullOrEmpty(query) ? "''" : String.Format("'{0}'", query);
                es = channel.GetContainersEntities(container.Id, theQuery);
                foreach (var item in es)
                {
                    item.Container = container;
                }
            }
            return es;
        }

        private static void GetEntity(Authority a, string container, string entity)
        {
            WebChannelFactory<IContainer> cf = GetChannelFactory(a);
            IContainer channel = cf.CreateChannel();

            using (new OperationContextScope((IContextChannel)channel))
            {
                SSDSEntityFormatter ef = channel.GetEntity(container, entity);
            }
        }

        private static void GetAuthority(string authority)
        {
            Authority a = new Authority { Id = authority };
            WebChannelFactory<IContainer> cf = GetChannelFactory(a);
            IContainer channel = cf.CreateChannel();
            using (new OperationContextScope((IContextChannel)channel))
            {
                OutgoingWebRequestContext ctx = WebOperationContext.Current.OutgoingRequest;
                ctx.Accept = ContentType;
                Authority auth = channel.GetAuthority();
                IncomingWebResponseContext rctx = WebOperationContext.Current.IncomingResponse;
                if (rctx.StatusCode == System.Net.HttpStatusCode.OK)
                    Console.WriteLine("Authority {0} {1} retrieved!", auth.Id, auth.Version);
            }
        }
        private static void UpdateEntity(Authority a, string container, string entity, SSDSEntityFormatter theEntity)
        {
            WebChannelFactory<IContainer> cf = GetChannelFactory(a);
            IContainer channel = cf.CreateChannel();

            using (new OperationContextScope((IContextChannel)channel))
            {
                OutgoingWebRequestContext ctx = WebOperationContext.Current.OutgoingRequest;
                ctx.ContentType = ContentType;
                channel.UpdateEntity(container, entity, theEntity);
                IncomingWebResponseContext rctx = WebOperationContext.Current.IncomingResponse;
                if (rctx.StatusCode == System.Net.HttpStatusCode.OK)
                    Console.WriteLine("Entity {0} deleted!", entity);

            }
        }
        private static void DeleteEntity(Authority a, string container, string entity)
        {
            WebChannelFactory<IContainer> cf = GetChannelFactory(a);
            IContainer channel = cf.CreateChannel();

            using (new OperationContextScope((IContextChannel)channel))
            {
                OutgoingWebRequestContext ctx = WebOperationContext.Current.OutgoingRequest;
                ctx.ContentType = ContentType;
                channel.DeleteEntity(container, entity);
                IncomingWebResponseContext rctx = WebOperationContext.Current.IncomingResponse;
                if (rctx.StatusCode == System.Net.HttpStatusCode.OK)
                    Console.WriteLine("Entity {0} deleted!", entity);

            }
        }
        
        private static void CreateEntity(Authority a, string container, string entity)
        {
            WebChannelFactory<IContainer> cf = GetChannelFactory(a);
            Container c = new Container { Id = container };
            IContainer channel = cf.CreateChannel();
            SSDSEntityFormatter flexEntity = new DerivedSSDSEntityFormatter();
            flexEntity.Name = "Test";
            flexEntity.Id = entity;
            StringProperty property = new StringProperty
            {
                StringValue = "Testing",
                Name = "TestElement"
            };
            List<SSDSEntityFlexibleProperty> props = new List<SSDSEntityFlexibleProperty>();
            props.Add(property);
            flexEntity.FlexibleProperties = props;
            using (new OperationContextScope((IContextChannel)channel))
            {
                //OutgoingWebRequestContext ctx = WebOperationContext.Current.OutgoingRequest;
                //ctx.ContentType = ContentType;
                channel.CreateEntity(container, flexEntity);
                IncomingWebResponseContext rctx = WebOperationContext.Current.IncomingResponse;
                if (rctx.StatusCode == System.Net.HttpStatusCode.Created)
                    Console.WriteLine("Entity {0} created!", entity);

            }
        }
        internal static void CreateContainer(this Container  c)
        {
            CreateContainer(c.Authority, c.Id);
        }
        private static void CreateContainer(Authority a, string container)
        {
            if (a!=null)
            {
                WebChannelFactory<IContainer> cf = GetChannelFactory(a);
                Container c = new Container { Id = container };
                IContainer channel = cf.CreateChannel();
                using (new OperationContextScope((IContextChannel)channel))
                {
                    OutgoingWebRequestContext ctx = WebOperationContext.Current.OutgoingRequest;
                    ctx.ContentType = ContentType;
                    channel.CreateContainer(c);
                    IncomingWebResponseContext rctx = WebOperationContext.Current.IncomingResponse;
                    if (rctx.StatusCode == System.Net.HttpStatusCode.Created)
                        Console.WriteLine("Container {0} created!", container);

                } 
            }
        }
        private static WebChannelFactory<IContainer> GetChannelFactory(Authority a)
        {
            //create the WebHttpBinding, and set its properties
            WebHttpBinding binding = new WebHttpBinding();
            binding.Security.Mode = WebHttpSecurityMode.TransportCredentialOnly;
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            //SDSS sends back chunked responses
            binding.TransferMode = TransferMode.StreamedResponse;
            //Copy the WebHttpBinding into a CustomBinding
            CustomBinding custom = new CustomBinding(binding);
            //Get the encoding element
            WebMessageEncodingBindingElement be =
                custom.Elements.Find<WebMessageEncodingBindingElement>();
            //set the content type mapper
            be.ContentTypeMapper = new SDSSContentTypeMapper();
            //create the URI
            string uri = String.Format(AuthorityUri, a.Id);
            //create the WebChannelFactory
            WebChannelFactory<IContainer> cf =
                new WebChannelFactory<IContainer>(custom,
                                                        new Uri(uri));
            cf.Endpoint.Behaviors.Add(new ContentTypeBehavior { ContentType = ContentType });
            //set the credentials
            cf.Credentials.UserName.UserName = Username;
            cf.Credentials.UserName.Password = Password;
            return cf;
        }
        private static void CreateAuthority(string authorityId)
        {
            WebHttpBinding binding = new WebHttpBinding();
            binding.Security.Mode = WebHttpSecurityMode.TransportCredentialOnly;
            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            WebChannelFactory<ICreateAuthority> cf =
                new WebChannelFactory<ICreateAuthority>(binding,
                                                        new Uri(ServiceUri));
            cf.Credentials.UserName.UserName = Username;
            cf.Credentials.UserName.Password = Password;
            Authority authority = new Authority { Id = authorityId };
            ICreateAuthority channel = cf.CreateChannel();
            using (new OperationContextScope((IContextChannel)channel))
            {
                OutgoingWebRequestContext ctx = WebOperationContext.Current.OutgoingRequest;
                ctx.ContentType = ContentType;
                channel.CreateAuthority(authority);
                IncomingWebResponseContext rctx = WebOperationContext.Current.IncomingResponse;
                if (rctx.StatusCode == System.Net.HttpStatusCode.Created)
                    Console.WriteLine("Authority {0} created!", authorityId);
            }
        }

        static string ContentType = "application/x-ssds+xml";
        static string Username = "jonflanders1";
        static string Password = "LT1#YF#WMxgsSBeDCNiD";
        static string ServiceUri = "http://data.beta.mssds.com/v1/";
        static string AuthorityUri = "http://{0}.data.beta.mssds.com/v1/";

    }
}
