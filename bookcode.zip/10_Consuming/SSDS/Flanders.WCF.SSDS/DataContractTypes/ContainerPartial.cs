﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Flanders.WCF.SSDS;

namespace schemas.microsoft.com.sitka._2008._03
{
    public partial class Container
    {
        public Authority Authority { get; set; }
        public EntitySet Entities
        {
            get
            {
                if (_entities == null)
                    _entities = this.GetEntities();
                return _entities;
            }
        }
        EntitySet _entities;
    }
}
