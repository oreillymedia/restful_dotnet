﻿using System.Collections.Generic;
using System.Xml.Serialization;
namespace Flanders.WCF.SSDS
{
    [XmlRoot("EntitySet", Namespace = "http://schemas.microsoft.com/sitka/2008/03/")]
    public partial class EntitySet : IXmlSerializable,IList<SSDSEntityFormatter>,IEnumerable<SSDSEntityFormatter>
    {


        List<SSDSEntityFormatter> Entities;

        #region IXmlSerializable Members

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(System.Xml.XmlReader reader)
        {
            List<SSDSEntityFormatter> entities = new List<SSDSEntityFormatter>();

            SSDSEntityFormatter temp;

            while (reader.Read())
            {
                if (reader.NodeType == System.Xml.XmlNodeType.Element)
                {
                    temp = new SSDSEntityFormatter();
                    temp.ReadXml(reader);
                    entities.Add(temp);
                }
            }
            this.Entities = entities;
        }

        public void WriteXml(System.Xml.XmlWriter writer)
        {

        }

        #endregion

        #region IList<SSDSEntityFormatter> Members

        public int IndexOf(SSDSEntityFormatter item)
        {
            return this.Entities.IndexOf(item);
        }

        public void Insert(int index, SSDSEntityFormatter item)
        {
             this.Entities.Insert(index, item);
        }

        public void RemoveAt(int index)
        {
            this.Entities.RemoveAt(index);
        }

        public SSDSEntityFormatter this[int index]
        {
            get
            {
                return this.Entities[index];
            }
            set
            {
                this.Entities[index] = value;
            }
        }

        #endregion

        #region ICollection<SSDSEntityFormatter> Members

        public void Add(SSDSEntityFormatter item)
        {
            this.Entities.Add(item);
        }

        public void Clear()
        {
            this.Entities.Clear();
        }

        public bool Contains(SSDSEntityFormatter item)
        {
            return this.Entities.Contains(item);
        }

        public void CopyTo(SSDSEntityFormatter[] array, int arrayIndex)
        {
            this.Entities.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return this.Entities.Count ; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public bool Remove(SSDSEntityFormatter item)
        {
            return this.Entities.Remove(item);
        }

        #endregion

        #region IEnumerable<SSDSEntityFormatter> Members

        public IEnumerator<SSDSEntityFormatter> GetEnumerator()
        {
            return this.Entities.GetEnumerator();
        }

        #endregion

        #region IEnumerable Members

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.Entities.GetEnumerator();
        }

        #endregion

        #region IEnumerable<SSDSEntityFormatter> Members

        IEnumerator<SSDSEntityFormatter> IEnumerable<SSDSEntityFormatter>.GetEnumerator()
        {
            return this.Entities.GetEnumerator();
        }

        #endregion
    } 
}