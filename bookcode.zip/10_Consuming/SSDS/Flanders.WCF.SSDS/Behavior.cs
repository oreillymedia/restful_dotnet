﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;

namespace Flanders.WCF.SSDS
{
public class ContentTypeBehavior : IEndpointBehavior
{
    public string ContentType { get; set; }
    #region IEndpointBehavior Members

    public void AddBindingParameters(ServiceEndpoint endpoint, System.ServiceModel.Channels.BindingParameterCollection bindingParameters)
    {

    }

    public void ApplyClientBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.ClientRuntime clientRuntime)
    {
        ContentTypeMessageInspector mi = null;
        mi = new ContentTypeMessageInspector { ContentType = this.ContentType };
        clientRuntime.MessageInspectors.Add(mi);
    }

    public void ApplyDispatchBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.EndpointDispatcher endpointDispatcher)
    {

    }

    public void Validate(ServiceEndpoint endpoint)
    {

    }

    #endregion
}
public class ContentTypeMessageInspector : IClientMessageInspector
{
    public string ContentType { get; set; }
    #region IClientMessageInspector Members

    public void AfterReceiveReply(ref System.ServiceModel.Channels.Message reply, object correlationState)
    {

    }

    public object BeforeSendRequest(ref System.ServiceModel.Channels.Message request, System.ServiceModel.IClientChannel channel)
    {
        HttpRequestMessageProperty prop = 
                        request.Properties[HttpRequestMessageProperty.Name] as 
                                                                HttpRequestMessageProperty;
        if (prop != null && (prop.Method=="POST"||prop.Method=="PUT"))
        {
            prop.Headers["Content-Type"] = this.ContentType;
        }
        return null;
    }

    #endregion
}

}
