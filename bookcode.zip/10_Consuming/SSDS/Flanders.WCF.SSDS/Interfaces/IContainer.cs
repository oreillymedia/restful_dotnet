﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using schemas.microsoft.com.sitka._2008._03;
using System.ServiceModel.Channels;

namespace Flanders.WCF.SSDS
{
    [ServiceContract]
    [ServiceKnownType(typeof(DerivedSSDSEntityFormatter))]
    public interface IContainer
    {
        //gets an Authority
        [WebGet(UriTemplate = "/")]
        [OperationContract]
        Authority GetAuthority();
        //queries an authority
        [WebGet(UriTemplate = "/?q={query}")]
        [OperationContract]
        ContainerEntitySet GetContainers(string query);
        //creates a Container
        [WebInvoke(UriTemplate = "/", Method = "POST")]
        [OperationContract]
        Container CreateContainer(Container container);
        //gets a Container
        [WebGet(UriTemplate = "/{containerid}")]
        [OperationContract]
        Container GetContainer(string containerid);
        //queries the container for entities  q='' returns all entities
        [WebGet(UriTemplate = "/{containerid}?q={query}")]
        [OperationContract]
        EntitySet GetContainersEntities(string containerid, string query);
        //Deletes a Container
        [WebInvoke(UriTemplate = "/{containerid}", Method = "DELETE")]
        [OperationContract]
        void DeleteContainer(string containerid);
        //Creates an Entity
        [WebInvoke(UriTemplate = "/{containerid}", Method = "POST")]
        [OperationContract]
        [XmlSerializerFormat()]
        void CreateEntity(string containerid, SSDSEntityFormatter body);
        //Gets an Entity
        [WebGet(UriTemplate = "/{containerid}/{entityid}")]
        [OperationContract]
        [XmlSerializerFormat()]
        SSDSEntityFormatter GetEntity(string containerid, string entityid);
        //Deletes an Entity
        [WebInvoke(UriTemplate = "/{containerid}/{entityid}", Method = "DELETE")]
        [OperationContract]
        void DeleteEntity(string containerid, string entityid);
        //Updates an Entity
        [WebInvoke(UriTemplate = "/{containerid}/{entityid}", Method = "UPDATE")]
        [OperationContract]
        [XmlSerializerFormat()]
        void UpdateEntity(string containerid, string entityid, SSDSEntityFormatter body);
    }
    
}
