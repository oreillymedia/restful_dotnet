﻿using schemas.microsoft.com.sitka._2008._03;
using System.ServiceModel.Web;
using System.ServiceModel;

namespace Flanders.WCF.SSDS
{
    [ServiceContract]
    public interface ICreateAuthority
    {
        [WebInvoke(Method = "POST", UriTemplate = "/")]
        [OperationContract()]
        void CreateAuthority(Authority authority);
    }
}
